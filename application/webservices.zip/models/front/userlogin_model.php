<?php
 class Userlogin_model extends CI_Model {
	function __construct()
	{
       parent::__construct();
	   $this->load->database();
	}
	/* Add New Role */	
	public function user_registration($post)
	{
		$this->db->insert('tbl_user', $post);
		$this->result = $this->db->insert_id() ; 
		return $this->result ;
	}

	/* Edit details */	
	public function checkUserEmailId($email_id)
	{
		$this->db->select('*');
		$this->db->from('tbl_user');
		$this->db->where('user_email', $email_id);
		$query = $this->db->get();
		return $query->result();
	}

	public function checkUserLogin($post)
	{
		$this->db->select('*');
		$this->db->from('tbl_user');
		$this->db->where('user_email', $post['user_email']);
		$this->db->where('user_password', $post['user_password']);
		$this->db->where('user_status', '1');
		$query = $this->db->get();
		return $query->result();
	}
}
?>