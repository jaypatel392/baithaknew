<?php

 class products_model extends CI_Model {
	function __construct()
	{
       parent::__construct();
	   $this->load->database();
	}
	
  public function getAllcategories()
	{
	
	$this->db->select('*');
        $this->db->from('tbl_category');
        $this->db->where('category_status', '1');
        $this->db->where('category_type', 'Product');
        $query = $this->db->get();
        return $query->result();   

	}


	public function getProducts(){


	$this->db->select('*');
	$this->db->from('tbl_product');
	$this->db->join('tbl_category', 'tbl_category.category_parent_id = tbl_product.product_parent_cat_id' ); 

	$query = $this->db->get();
	return $query->result();

	}


	public function getNewProduct(){
        
        $this->db->select('a.*,b.*');
        $this->db->from('tbl_product a');
        $this->db->join('tbl_discount b', 'a.product_discount_id = b.discount_id');
        $this->db->order_by('a.product_updated_date', 'DESC');
        $this->db->where('a.product_status', '1');
        $query = $this->db->get();
        return $query->result();
       }



	public function getBrands(){

	$this->db->select('*');
        $this->db->from('tbl_brand');
        $this->db->where('brand_status', '1');
        $query = $this->db->get();
        return $query->result();
	}

	public function getProductByCategoryId($category_id){

			$this->db->select('a.*,b.*');
			$this->db->from('tbl_product a');
                        $this->db->join('tbl_discount b', 'a.product_discount_id = b.discount_id');
			$this->db->where('product_parent_cat_id',$category_id);
			$this->db->where('product_status','1');
			$query = $this->db->get();	
			return $query->result();
	}

	public function getThreeProductImage($product_id){

			$this->db->select('*');
			$this->db->from('tbl_product_img');
			$this->db->where('product_id',$product_id);
			$this->db->where('product_img_status','1');
			$query = $this->db->get();	
			return $query->result();
	}


	///****************** Cart Product Start **************************

	public function getCartProductById($product_id){
			$this->db->select('*');
			$this->db->from('tbl_product');
			// $this->db->join('tbl_discount b', 'b.discount_id = a.product_discount_id' );
            $this->db->where('product_id',$product_id);  			
			$query = $this->db->get();	
			return $query->result();
	}

	public function getProductByCategoryIdAndPrice($category_id,$minPrice,$maxPrice)
   {
		$this->db->select('*');
		$this->db->from('tbl_product');
		$this->db->where('product_parent_cat_id',$category_id);
		$this->db->where('product_status','1');
		if($minPrice == '0'){
		$this->db->where('product_sale_price <=', $maxPrice);

		}
		elseif ($maxPrice == '0') {
		$this->db->where('product_sale_price >=',$minPrice);
		}
		else{
		$this->db->where('product_sale_price >=',$minPrice);
		$this->db->where('product_sale_price <=',$maxPrice);

		}
		$query = $this->db->get();	
		return $query->result();
}



public function getSortedProduct($cat_id,$sortBy)
	
	{
	    $this->db->select('*');
		$this->db->from('tbl_product');
		$this->db->where('product_parent_cat_id',$cat_id);
		$this->db->where('product_status','1');
	  if($sortBy == 'newproduct')
	    {
	  	$this->db->order_by('product_updated_date', 'DESC');
        }
     if($sortBy == 'price_lowtohigh')
        {
        $this->db->order_by('product_sale_price','asc');

        }

     if($sortBy == 'price_hightolow')
        {
        	$this->db->order_by('product_sale_price','DESC');

        }

        $query = $this->db->get();	
		return $query->result();

	}

public function addCartproducts($post){

  		$this->db->insert('tbl_cart', $post);
		$this->result = $this->db->insert_id() ; 
		return $this->result ;
  }

  public function addCartproductsAttr($post){

  		$this->db->insert('tbl_cart_attr', $post);
		$this->result = $this->db->insert_id() ; 
		return $this->result ;
  }

	
}
?>