<!-- banner -->
  <!-- <div class="banner banner1">
    <div class="container">
      <h2>Great Offers on <span>Mobiles</span> Flat <i>35% Discount</i></h2> 
    </div>
  </div>  -->
  <!-- breadcrumbs -->
  <div class="breadcrumb_dress">
    <div class="container">
      <ul>
        <li><a href="<?php echo base_url();?>"><span class="glyphicon glyphicon-home" aria-hidden="true"></span> Home</a> <i>/</i></li>
        <li>Products</li>
      </ul>
    </div>
  </div>
  <!-- //breadcrumbs --> 
 <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>webroot/front/css/checkout_style.css">
    <!-- multistep form -->
      <form id="msform">
         <!-- progressbar -->
         <ul id="progressbar">           
            <li class="active">Basic Info</li>
            <li>Delivery Address</li>
            <li>Billing Address</li>           
            
         </ul>
         <!-- fieldsets -->
         <fieldset>
            <h2 class="fs-title">Basic Information</h2>
            <!-- <h3 class="fs-subtitle">This is step 1</h3> -->
            <?php foreach ($user_details as $user_value) {
              $user_name = explode(' ', $user_value->user_name);
             ?>
            <input type="text" name="user_fname" id="user_fname" placeholder="First Name" value="<?php echo $user_name[0];?>"  />
            <span id="error_user_fname" style="color: red;"></span>
            <input type="text" name="user_lname" id="user_lname" placeholder="Last Name" value="<?php echo $user_name[1];?>" />
            <span id="error_user_lname" style="color: red;"></span>
            <input type="text" name="user_email_id" id="user_email_id" placeholder="Email address" value="<?php echo $user_value->user_email;?>" />
           <span id="error_user_email_id" style="color: red;"></span>         
                    
            <input type="text" name="user_phone" id="user_phone" placeholder="Phone Number" alue="<?php echo $user_value->user_phone;?>"/>
            <span id="error_user_phone" style="color: red;"></span>
            <br>           
            <input type="button" name="previous" class="previous action-button" value="Previous" />
            <input type="button" name="next" class="next action-button" value="Next" />
            <?php } ?>
         </fieldset>
          <fieldset>
            <h2 class="fs-title">Delivery Address</h2>
            <!-- <h3 class="fs-subtitle">We will never sell it</h3> -->
           <select onchange="getStateList(this.value)" id="user_country" name="user_country"> 
           <option value="">Select Country</option>
           <?php foreach ($country_list as $cntr_value) {
             ?>
             <option value="<?php echo $cntr_value->country_id;?>"><?php echo $cntr_value->country_name;?></option>
            <?php
            } ?>

           </select>
            <span id="error_user_country" style="color: red;"></span>
            <select id="user_state" name="user_state"> 
              <option value="">Select State</option> 
           </select>
            <span id="error_user_state" style="color: red;"></span>
            <input type="text" name="usre_postal_code" id="usre_postal_code" placeholder="Pin Code"  />  
             <span id="error_user_pin_code" style="color: red;"></span>        
             <textarea name="user_address_line_1" id="user_address_line_1" placeholder="Address Line 1"></textarea>
              <span id="error_user_addrs_line1" style="color: red;"></span>
             <textarea name="user_address_line_2" placeholder="Address Line 2"></textarea>
           
            <input type="button" name="previous" class="previous action-button" value="Previous" />
            <input type="button" name="next" class="next action-button" value="Next" />
           
            
         </fieldset>
         <fieldset>
            <h2 class="fs-title">Delivery Address</h2>
            <!-- <h3 class="fs-subtitle">We will never sell it</h3> -->
           <select onchange="getStateList(this.value)" id="user_country" name="user_country"> 
           <option value="">Select Country</option>
           <?php foreach ($country_list as $cntr_value) {
             ?>
             <option value="<?php echo $cntr_value->country_id;?>"><?php echo $cntr_value->country_name;?></option>
            <?php
            } ?>

           </select>
            <span id="error_user_country" style="color: red;"></span>
            <select id="user_state" name="user_state"> 
              <option value="">Select State</option> 
           </select>
            <span id="error_user_state" style="color: red;"></span>
            <input type="text" name="usre_postal_code" id="usre_postal_code" placeholder="Pin Code"  />  
             <span id="error_user_pin_code" style="color: red;"></span>        
             <textarea name="user_address_line_1" id="user_address_line_1" placeholder="Address Line 1"></textarea>
              <span id="error_user_addrs_line1" style="color: red;"></span>
             <textarea name="user_address_line_2" placeholder="Address Line 2"></textarea>
           
            <input type="button" name="previous" class="previous action-button" value="Previous" />
            <input type="submit" name="next" class="submit action-button" value="Pay" />
           
            
         </fieldset>
      </form>
      <!-- jQuery --> 
     
      <script src="<?php echo base_url();?>webroot/front/js/jquery.easing.min.js" type="text/javascript"></script> 
      <script>
         $(function() {
         
         //jQuery time
         var current_fs, next_fs, previous_fs; //fieldsets
         var left, opacity, scale; //fieldset properties which we will animate
         var animating; //flag to prevent quick multi-click glitches
         
         $(".next").click(function(){

           if($('#user_fname').val() == ''){               
                $('#error_user_fname').html('First name is required* <br>');
                $("#user_fname").focus();                
                document.getElementById('user_fname').style.border='1px solid red';
                return false;
           }else{   

              $('#error_user_fname').html('');
              document.getElementById('user_fname').style.border='1px solid green';
                
           }

            if($('#user_lname').val() == ''){               
                $('#error_user_lname').html('Last name is required*<br>');
                $("#user_lname").focus();                
                document.getElementById('user_lname').style.border='1px solid red';
                return false;
           }else{   

              $('#error_user_lname').html('');
              document.getElementById('user_lname').style.border='1px solid green';
                
           }

            if($('#user_email_id').val() == ''){               
                $('#error_user_email_id').html('Email address is required* <br>');
                $("#user_email_id").focus();                
                document.getElementById('user_email_id').style.border='1px solid red';
                return false;
            }else{   

              $('#error_user_email_id').html('');
              document.getElementById('user_email_id').style.border='1px solid green';
                
           }
            if($('#user_phone').val() == ''){               
                $('#error_user_phone').html('Phone number is required*<br>');
                $("#user_phone").focus();                
                document.getElementById('user_phone').style.border='1px solid red';
                return false;
            }else{   

              $('#error_user_phone').html('');
              document.getElementById('user_phone').style.border='1px solid green';
                
            }            
           
                   
          if(animating) return false;
          animating = true;
          
          current_fs = $(this).parent();
          next_fs = $(this).parent().next();
          
          //activate next step on progressbar using the index of next_fs
          $("#progressbar li").eq($("fieldset").index(next_fs)).addClass("active");
          
          //show the next fieldset
          next_fs.show(); 
          //hide the current fieldset with style
          current_fs.animate({opacity: 0}, {
            step: function(now, mx) {
              //as the opacity of current_fs reduces to 0 - stored in "now"
              //1. scale current_fs down to 80%
              scale = 1 - (1 - now) * 0.2;
              //2. bring next_fs from the right(50%)
              left = (now * 50)+"%";
              //3. increase opacity of next_fs to 1 as it moves in
              opacity = 1 - now;
              current_fs.css({'transform': 'scale('+scale+')'});
              next_fs.css({'left': left, 'opacity': opacity});
            }, 
            duration: 100, 
            complete: function(){
              current_fs.hide();
              animating = false;
            }, 
            //this comes from the custom easing plugin
            easing: 'easeInOutBack'
          });
         });
         
         $(".previous").click(function(){
          if(animating) return false;
          animating = true;
          
          current_fs = $(this).parent();
          previous_fs = $(this).parent().prev();
          
          //de-activate current step on progressbar
          $("#progressbar li").eq($("fieldset").index(current_fs)).removeClass("active");
          
          //show the previous fieldset
          previous_fs.show(); 
          //hide the current fieldset with style
          current_fs.animate({opacity: 0}, {
            step: function(now, mx) {
              //as the opacity of current_fs reduces to 0 - stored in "now"
              //1. scale previous_fs from 80% to 100%
              scale = 0.8 + (1 - now) * 0.2;
              //2. take current_fs to the right(50%) - from 0%
              left = ((1-now) * 50)+"%";
              //3. increase opacity of previous_fs to 1 as it moves in
              opacity = 1 - now;
              current_fs.css({'left': left});
              previous_fs.css({'transform': 'scale('+scale+')', 'opacity': opacity});
            }, 
            duration: 100, 
            complete: function(){
              current_fs.hide();
              animating = false;
            }, 
            //this comes from the custom easing plugin
            easing: 'easeInOutBack'
          });
         });
         
         $(".submit").click(function(){
          return false;
         })
         
         });
      </script>
      <script type="text/javascript">
         var _gaq = _gaq || [];
         _gaq.push(['_setAccount', 'UA-36251023-1']);
         _gaq.push(['_setDomainName', 'jqueryscript.net']);
         _gaq.push(['_trackPageview']);
         
         (function() {
           var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
           ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
           var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
         })();


  function getStateList(country_id)
    {
        var str = 'country_id='+country_id;
        var PAGE = '<?php echo base_url(); ?>products/getStateList';
        
        jQuery.ajax({
            type :"POST",
            url  :PAGE,
            data : str,
            success:function(data)
            {           
                if(data != "")
                {
                    $('#user_state').html(data);
                }
                else
                {
                    $('#user_state').html('<option value=""></option>');
                }
            } 
        });
    }
</script>
