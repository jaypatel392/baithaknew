<div class="banner banner1">
		<div class="container">
			<h2>Great Offers on <span>Mobiles</span> Flat <i>35% Discount</i></h2> 
		</div>
	</div> 
	<!-- breadcrumbs -->
	<div class="breadcrumb_dress">
		<div class="container">
			<ul>
				<li><a href="<?php echo base_url();?>"><span class="glyphicon glyphicon-home" aria-hidden="true"></span> Home</a> <i>/</i></li>
				<li>Products</li>
			</ul>
		</div>
	</div>
	<!-- //breadcrumbs --> 
	<!-- mobiles -->
	<div class="mobiles">
		<div class="container">
			<div class="w3ls_mobiles_grids">
				<div class="col-md-4 w3ls_mobiles_grid_left">
					<div class="w3ls_mobiles_grid_left_grid">
						<h3>Categories</h3>
						<div class="w3ls_mobiles_grid_left_grid_sub">
							<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
							  <div class="panel panel-default">
						
								<div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
								  <div class="panel-body panel_text">
								  <input type="hidden" name="hiddenCategory" id="hiddenCategory" value="<?php echo $this->uri->segment(3);?>">
									<ul>
									<?php foreach ($categories as $value) { ?>	
									
										<li style="cursor: pointer;" onclick="getFilterProductBygetegoryId('<?php echo $value->category_id;?>')"><span class= "Categories" id ="<?php echo $value->category_id;?>" ><?php echo $value->category_name;?></span></li>
										<?php } ?>
										
									</ul>
								  </div>
								</div>
							  </div>
						
							</div>
							
						</div>
					</div>					
					<div class="w3ls_mobiles_grid_left_grid">
						<h3>Price</h3>
						<div class="w3ls_mobiles_grid_left_grid_sub">
							<div class="ecommerce_color ecommerce_size">
								<ul>
									<li onclick="getProductByPrice('0','1000')"><a href="javascript:void(0)">Below INR 1000</a></li>
									<li onclick="getProductByPrice('1000','5000')"><a href="javascript:void(0)">INR 1000-5000</a></li>
									<li onclick="getProductByPrice('5000','10000')"><a href="javascript:void(0)">INR 5000-10000</a></li>
									<li onclick="getProductByPrice('10000','20000')"><a href="javascript:void(0)">INR 10000-20000</a></li>
									<li onclick="getProductByPrice('20000','0')" ><a href="javascript:void(0)">INR Above 20000</a></li>
								</ul>
							</div>
						</div>
					</div>
				</div>
				<div class="col-md-8 w3ls_mobiles_grid_right">
					
					
					<div class="clearfix"> </div>

					<div class="w3ls_mobiles_grid_right_grid2">
						<div class="w3ls_mobiles_grid_right_grid2_left">
							<h3>Showing Results: 0-1</h3>
						</div>
						<div class="w3ls_mobiles_grid_right_grid2_right">
							<select name="productsort" id ="sortProduct" class="select_item" onchange="sortProduct(this.value)">
								<option value =""selected="selected">Default sorting</option>
								<option value="rating">Sort by popularity</option>
								<option value ="rating">Sort by average rating</option>
								<option value = "newproduct">Sort by newness</option>
								<option value ="price_lowtohigh">Sort by price: low to high</option>
								<option value ="price_hightolow">Sort by price: high to low</option>
							</select>
						</div>
						<div class="clearfix"> </div>
					</div>
					<div id ="showfilterProductBycategory">
					<div class="w3ls_mobiles_grid_right_grid3">
					<?php foreach ($productsBycat as $value) { ?>

							<div class="col-md-4 agileinfo_new_products_grid agileinfo_new_products_grid_mobiles">
							<div class="agile_ecommerce_tab_left mobiles_grid">
								<div class="hs-wrapper hs-wrapper2">
								<?php $products_imgs =  $this->products_model->getThreeProductImage($value->product_id);
								foreach ($products_imgs as $valueImg) { ?>
									<img src="<?php echo $valueImg->product_img_name;?>" alt=" " class="img-responsive" />
								 <?php } ?>
									
									
									<div class="w3_hs_bottom w3_hs_bottom_sub1">
										<ul>
											<li>
												<a href="#" data-toggle="modal" data-target="#myModal9"><span class="glyphicon glyphicon-eye-open" aria-hidden="true"></span></a>
											</li>
										</ul>
									</div>
								</div>
								<h5><a href="<?php echo base_url().'singleproduct/viewProductDetail/'.$value->product_id;?>"><?php echo $value->product_title;?></a></h5> 
								<div class="simpleCart_shelfItem">
									<p><i class="item_price">Rs <?php echo $value->product_sale_price;?></i></p>
									  <?php 									  
										  $cart_details = $this->cart->contents();
										   $check_cart=0;
										  foreach ($cart_details as $cart_value) {
										  	 if($cart_value['id'] == $value->product_id){
										       $check_cart++;
										      }
										  }
										  if($check_cart){
										  ?>
										  <a href="<?php echo base_url();?>products/viewCart"><button type="button" class="w3ls-cart">Go to cart</button></a>
										  <?php }else{
										  	?>
										 <div id="add_crt_btn<?php echo $value->product_id;?>"><button type="button" onclick="productAddToCart('<?php echo $value->product_id;?>','<?php echo $this->uri->segment(3);?>')" class="w3ls-cart">Add to cart</button></div>
										  	<?php
										  	}
										  							  
									    ?>					
									
								</div> 
								<div class="mobiles_grid_pos">
									<h6>New</h6>
								</div>
							</div>
						</div>
						<?php } ?>
						
						<div class="clearfix"> </div>
					</div>
					</div>
					
			</div>
		</div>
	</div>  
	<!-- Related Products -->
	<div class="w3l_related_products">
		<div class="container">
			<h3>Related Products</h3>			
				
		</div>
	</div>
	<!-- //Related Products -->
	<!-- newsletter -->
	<script type="text/javascript">
    
           function getFilterProductBygetegoryId(category_id){
            $.ajax({
                type: "post",
                url: "<?php echo base_url().'products/getProductsByCatId';?>",
                data: "cat_id="+ category_id,
                cache: false,
			    beforeSend: function () {
			    $('#showfilterProductBycategory').html('<br><center><img src="<?php echo base_url();?>webroot/clientloader.gif" alt="Please wait..." style="width: 60px;"></center>');	        
			     },   
                success: function(data) {
                	//alert(data);return false;
                    if(data){
                    	
                       $('#showfilterProductBycategory').html(data);
                       $('#hiddenCategoriyId').val(category_id);
                    }else{
                    	$('#showfilterProductBycategory').html('<br><br><h4 style="color:red; text-align:center;">Product Not Found!</h4>');
                    }
                }
            });
            return false;
        }

        function getProductByPrice(min_price,max_price){
	   
	  // alert(min_price); return false;
 	   var cat_id = $('#hiddenCategory').val();
 	   var dataString = 'cat_id=' + cat_id + '&min_price=' + min_price + '&max_price='+max_price; 	
           	 $.ajax({
                type: "post",
                url: "<?php echo base_url().'products/getProductsByCatIdAndPrice';?>",
                data: dataString,
                cache: false,
			    beforeSend: function () {
			    $('#showfilterProductBycategory').html('<br><center><img src="<?php echo base_url();?>webroot/clientloader.gif" alt="Please wait..." style="width: 60px;"></center>');	        
			     },    
                success: function(data) {
                	
                    if(data){
                    	//alert(data)
                       $('#showfilterProductBycategory').html(data);
                       $('#hiddenCategory').val(category_id);
                      }else{
                    	$('#showfilterProductBycategory').html('<br><br><h4 style="color:red; text-align:center;">Product Not Found!</h4>');
                    }
                }
            });
            
        }

   function sortProduct(productSortBy){
   		var cat_id = $('#hiddenCategory').val();
 	   var dataString = 'sortingBy=' +productSortBy + '&cat_id=' + cat_id; 	
           	 $.ajax({
                type: "post",
                url: "<?php echo base_url().'products/getsortedProducts';?>",
                data: dataString,
                cache: false,
			    beforeSend: function () {
			    $('#showfilterProductBycategory').html('<br><center><img src="<?php echo base_url();?>webroot/clientloader.gif" alt="Please wait..." style="width: 60px;"></center>');	        
			     },  
                success: function(data) {
                	
                    if(data){
                    	//alert(data)
                       $('#showfilterProductBycategory').html(data);
                       $('#hiddenCategory').val(category_id);
                      }else{
                    	$('#showfilterProductBycategory').html('<br><br><h4 style="color:red; text-align:center;">Product Not Found!</h4>');
                    }
                }
            });
            
        }
   
   
</script>