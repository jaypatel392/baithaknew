<!-- banner -->
  <div class="banner banner1">
    <div class="container">
      <h2>Great Offers on <span>Mobiles</span> Flat <i>35% Discount</i></h2> 
    </div>
  </div> 
  <!-- breadcrumbs -->
  <div class="breadcrumb_dress">
    <div class="container">
      <ul>
        <li><a href="<?php echo base_url();?>"><span class="glyphicon glyphicon-home" aria-hidden="true"></span> Home</a> <i>/</i></li>
        <li>Products</li>
      </ul>
    </div>
  </div>
  <!-- //breadcrumbs --> 
