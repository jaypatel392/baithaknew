	<div class="banner banner10">
		<div class="container">
			<h2>Single Page</h2>
		</div>
	</div>
	<!-- //banner -->   
	<!-- breadcrumbs -->
	<div class="breadcrumb_dress">
		<div class="container">
			<ul>
				<li><a href="<?php echo base_url();?>"><span class="glyphicon glyphicon-home" aria-hidden="true"></span> Home</a> <i>/</i></li>
				<li>Single Page</li>
			</ul>
		</div>
	</div>
	<!-- //breadcrumbs -->  
	<!-- single -->
	<form method="POST">
	<div class="single">
		<div class="container">
			<div class="col-md-4 single-left">
				<div class="flexslider">
					<ul class="slides">
					<li data-thumb="<?php echo $productDetail[0]->product_thumb_img;?>">
							<div class="thumb-image"> <img src="<?php echo $productDetail[0]->product_thumb_img;?>" data-imagezoom="true" class="img-responsive" alt=""> </div>
							<input type="hidden" name="crt_product_thumb_img" value="<?php echo $productDetail[0]->product_thumb_img;?>">
						</li>
					<?php foreach ($threeImg as $img_value) { ?>
						
					
						<li data-thumb="<?php echo $img_value->product_img_name;?>">
							<div class="thumb-image"> <img src="<?php echo $img_value->product_img_name;?>" data-imagezoom="true" class="img-responsive" alt=""> </div>
						</li>
						 <?php } ?>
					</ul>
				</div>
				<!-- flexslider -->
					<script defer src="<?php echo base_url().'webroot/front/js/jquery.flexslider.js';?>"></script>
					<link rel="stylesheet" href="<?php echo base_url().'webroot/front/css/flexslider.css';?>" type="text/css" media="screen" />
					<script>
					// Can also be used with $(document).ready()
					$(window).load(function() {
					  $('.flexslider').flexslider({
						animation: "slide",
						controlNav: "thumbnails"
					  });
					});
					</script>
				<!-- flexslider -->
				<!-- zooming-effect -->
					<script src="<?php echo base_url().'webroot/front/js/imagezoom.js';?>"></script>
				<!-- //zooming-effect -->
			</div>
			<div class="col-md-8 single-right">
				<h3><?php echo $productDetail[0]->product_title;?></h3>
				<input type="hidden" name="crt_product_id" value="<?php echo $productDetail[0]->product_id;?>">
				<input type="hidden" name="crt_product_title" value="<?php echo $productDetail[0]->product_title;?>">
				<input type="hidden" name="crt_product_price" value="<?php echo $productDetail[0]->product_sale_price;?>">
				<div class="rating1">
					<span class="starRating">
						<input id="rating5" type="radio" name="" value="5">
						<label for="rating5">5</label>
						<input id="rating4" type="radio" name="" value="4">
						<label for="rating4">4</label>
						<input id="rating3" type="radio" name="" value="3" checked>
						<label for="rating3">3</label>
						<input id="rating2" type="radio" name="" value="2">
						<label for="rating2">2</label>
						<input id="rating1" type="radio" name="" value="1">
						<label for="rating1">1</label>
					</span>
				</div>
				<div class="description">
				
					<h5><i>Description</i></h5>
					<p><?php echo $productDetail[0]->product_description;?></p>
				</div>				
				<?php foreach ($productAttributes as $attr_value) { ?>				
				
				<div class="occasional">
					<h5><?php echo $attr_value->attr_name;?>:</h5>					
					<?php 
					$attr_vals = $this->singleproduct_model->getAttrvalue($attr_value->attr_id);
					foreach ($attr_vals as  $valueAttr) { ?>						
					
					<div class="colr ert">
						<div class="check">
							<label class="checkbox"><input type="radio" checked name="product_attr_value<?php echo $attr_value->attr_id;?>" id="product_attr_value<?php echo $attr_value->attr_id;?>" value="<?php echo $valueAttr->attr_value;?>"><i> </i><?php echo $valueAttr->attr_value;?></label>
						</div>
					</div>
					<?php } ?>

					
					<div class="clearfix"> </div>
				</div>
				<?php  } ?>
				<!--endloop-->

				<div class="simpleCart_shelfItem">
					<p><i class="item_price">Rs <?php echo $productDetail[0]->product_sale_price;?></i></p>
					 <?php 									  
						  $cart_details = $this->cart->contents();
						   $check_cart=0;
						  foreach ($cart_details as $cart_value) {
						  	 if($cart_value['id'] == $this->uri->segment(3)){
						       $check_cart++;
						      }
						  }
						  if($check_cart){
						  ?>
						  <a href="<?php echo base_url();?>products/viewCart"><button type="button" class="w3ls-cart">Go to cart</button></a>
						  <?php }else{
						  	?>
						  	<div id="add_crt_btn<?php echo $this->uri->segment(3);?>">
						  	<button type="submit" name="Add_cart" class="w3ls-cart">Add to cart</button></div>
						  	<?php
						  	}						  							  
					    ?>				
				</div> 
			</div>
			<div class="clearfix"> </div>
		</div>
	</div> 
	</form>
	<div class="additional_info">
		<div class="container">
			<div class="sap_tabs">	
				<div id="horizontalTab1" style="display: block; width: 100%; margin: 0px;">
					<ul>
						<li class="resp-tab-item" aria-controls="tab_item-0" role="tab"><span>Product Information</span></li>
						<li class="resp-tab-item" aria-controls="tab_item-1" role="tab"><span>Reviews</span></li>
					</ul>		
					<div class="tab-1 resp-tab-content additional_info_grid" aria-labelledby="tab_item-0">
						<h3><?php echo $productDetail[0]->product_title;?></h3>
						<?php foreach ($specifications as $spc_value) { ?>
							<p>
							<?php echo $spc_value->specification_name;?> : <?php echo $spc_value->specification_val;?>
						</p>
						<?php } ?>
					</div>	

					<div class="tab-2 resp-tab-content additional_info_grid" aria-labelledby="tab_item-1">
						<h4>Reviews</h4>
						<?php foreach ($reviews as $rew_value) { ?>
							
					
						<div class="additional_info_sub_grids">
							<div class="col-xs-2 additional_info_sub_grid_left">
								<img src="<?php echo base_url().'webroot/front/images/t1.png';?>" alt=" " class="img-responsive" />
							</div>
							<div class="col-xs-10 additional_info_sub_grid_right">
								<div class="additional_info_sub_grid_rightl">
									<a href="single.html"><?php echo $rew_value->user_name;?></a>
									<h5><?php echo $rew_value->review_updated_date;?></h5>
									<p><?php echo $rew_value->review_description;?></p>
								</div>
								<div class="additional_info_sub_grid_rightr">
									<div class="rating">
									<?php for ($i=1; $i <= $rew_value->review_value ; $i++) {?>
										
								
										<div class="rating-left">
											<img src="<?php echo base_url().'webroot/front/images/star-.png';?>" alt=" " class="img-responsive">
										</div>
										<?php } ?>
										
										<div class="clearfix"> </div>
									</div>
								</div>
								<div class="clearfix"> </div>
							</div>
							<div class="clearfix"> </div>
						</div>
						<?php } ?>			        					            	      
				</div>	
			</div>
			<script src="<?php echo base_url().'webroot/front/js/easyResponsiveTabs.js';?>" type="text/javascript"></script>
			<script type="text/javascript">
				$(document).ready(function () {
					$('#horizontalTab1').easyResponsiveTabs({
						type: 'default', //Types: default, vertical, accordion           
						width: 'auto', //auto or any width like 600px
						fit: true   // 100% fit in a container
					});
				});
			</script>
		</div>
	</div>
			<script src="<?php echo base_url().'webroot/front/js/easyResponsiveTabs.js';?>" type="text/javascript"></script>
			<script type="text/javascript">
				$(document).ready(function () {
					$('#horizontalTab1').easyResponsiveTabs({
						type: 'default', //Types: default, vertical, accordion           
						width: 'auto', //auto or any width like 600px
						fit: true   // 100% fit in a container
					});
				});
			</script>
		</div>
	</div>
	<!-- Related Products -->
	<div class="w3l_related_products">
		<div class="container">
			<h3>Related Products</h3>
			<ul id="flexiselDemo2">
			<?php 
			 $relatedProducts = $this->singleproduct_model->getRelatedProducts($productDetail[0]->product_parent_cat_id);
			 foreach ($relatedProducts as  $relatedProduct) { ?>
			  			
			  			
				<li>
					<div class="w3l_related_products_grid">
						<div class="agile_ecommerce_tab_left mobiles_grid">
							<div class="hs-wrapper hs-wrapper3">
							<?php $productsImages = $this->singleproduct_model->getThreeProductImage($relatedProduct->product_id);
							foreach ($productsImages as  $productsImage) {
								?>
								
							
								<img src="<?php echo $productsImage->product_img_name;?>" alt=" " class="img-responsive" />
								<?php } ?>
								<div class="w3_hs_bottom">
									<div class="flex_ecommerce">
										<a href="<?php echo base_url().'singleproduct/viewProductDetail/'.$relatedProduct->product_id;?>" ><span class="glyphicon glyphicon-eye-open" aria-hidden="true"></span></a>
									</div>
								</div>
							</div>
							<h5><a href="<?php echo base_url().'singleproduct/viewProductDetail/'.$relatedProduct->product_id;?>"><?php echo $relatedProduct->product_title;?></a></h5>
							<div class="simpleCart_shelfItem"> 
								<p class="flexisel_ecommerce_cart"><span>$100</span> <i class="item_price"><?php echo $relatedProduct->product_sale_price;?></i></p><?php 									  
										  $cart_details = $this->cart->contents();
										   $check_cart=0;
										  foreach ($cart_details as $cart_value) {
										  	 if($cart_value['id'] == $value->product_id){
										       $check_cart++;
										      }
										  }
										  if($check_cart){
										  ?>
										  <a href="<?php echo base_url();?>products/viewCart"><button type="button" class="w3ls-cart">Go to cart</button></a>
										  <?php }else{
										  	?>
										  	<a href= "<?php echo base_url().'singleproduct/viewProductDetail/'.$value->product_id;?>" ><button type="button" class="w3ls-cart">Add to cart</button></a>
										  	<?php
										  	}
										  							  
									    ?>				
								
							</div>
						</div>
					</div>
				</li>
				<?php } ?>
			</ul>
			
				<script type="text/javascript">
					$(window).load(function() {
						$("#flexiselDemo2").flexisel({
							visibleItems:4,
							animationSpeed: 1000,
							autoPlay: true,
							autoPlaySpeed: 3000,    		
							pauseOnHover: true,
							enableResponsiveBreakpoints: true,
							responsiveBreakpoints: { 
								portrait: { 
									changePoint:480,
									visibleItems: 1
								}, 
								landscape: { 
									changePoint:640,
									visibleItems:2
								},
								tablet: { 
									changePoint:768,
									visibleItems: 3
								}
							}
						});
						
					});
				</script>
				<script type="text/javascript" src="<?php echo base_url().'webroot/front/js/jquery.flexisel.js';?>"></script>
		</div>
	</div>
	<!-- //Related Products -->
	
	<!-- newsletter -->
	