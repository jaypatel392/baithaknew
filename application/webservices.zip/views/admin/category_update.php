<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>	
			Category<small>Control panel</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo base_url();?>admin/dashboard"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="<?php echo base_url();?>admin/category">Category</a></li>
            <li class="active">Category Add</li>
        </ol>
    </section>
    <div>
        <div id="msg_div">
            <?php echo $this->session->flashdata('message');?>
        </div>
    </div>
    <!-- Main content -->
    <section class="content">       
        <div class="box">
            <div class="box-header">
                <div class="pull-left">
                    <h3 class="box-title">Category Add</h3>
                </div>
                <div class="pull-right box-tools">
                    <a href="<?php echo base_url();?>admin/category" class="btn btn-info btn-sm">Back</a>                           
                </div>
            </div>
            <form action="" method="post" accept-charset="utf-8" enctype="multipart/form-data">
            <?php
                foreach($category_edit as $res)
                    {

                      ?>
                <!-- /.box-header -->
                <div class="box-body">
                    <input name="category_id" type="hidden" id="category_id" value="<?php echo $res->category_id ;?>" />
                    <div class="row">
                        <div class="form-group col-md-6">
                            <div class="input text">
                                <label>Category Name<span class="text-danger">*</span></label>
                                <input name="category_name" class="form-control" type="text" id="category_name" value="<?php echo $res->category_name ;?>" />
                                <?php echo form_error('category_name','<span class="text-danger">','</span>'); ?>
                                <span id="error_categoryName" style="color: red;"></span>
                            </div>
                        </div>
                        <div class="form-group col-md-6">
                            <div class="input text">
                                <label>Category Type</label>
                                <select name="category_type" id="category_type" class="form-control" onchange="getParentCategory(this.value);">
                                    <option value=""></option>
                                    <option value="Event" <?php if($res->category_type == "Event"){  ?> selected <?php } ?>>Event</option>
                                    <option value="Product" <?php if($res->category_type == "Product"){  ?> selected <?php } ?> >Product</option>
                                </select>
                               
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group col-md-6">
                            <div class="input text">
                                <label>Parent Category</label>
                                <select name="category_parent_id" id="category_parent_id" class="form-control">
                                <option value="">Select parent category</option>
                                <?php
                                  foreach ($parent_category_list as $parant_res) {
                                     ?>
                                     <option value="<?php echo $parant_res->category_id;?>" <?php if($res->category_parent_id == $parant_res->category_id ) { ?> selected <?php } ?> ><?php echo $parant_res->category_name;?></option>
                                     <?php
                                  }
                                ?>
                             </select>
                            </div>
                        </div>
                        <div class="form-group col-md-6">
                            <div class="input text">
                                <label>Category Status</label>
                                <select name="category_status" id="category_status" class="form-control">                                   
                                    <option value="1" <?php if($res->category_status == '1') { ?> selected <?php } ?> >Active</option>
                                    <option value="0" <?php if($res->category_status == '0') { ?> selected <?php } ?>>Deactive</option>
                                </select>
                               
                            </div>
                        </div>
                        
                    </div>
                     <div class="row">
                      <div class="form-group col-md-6">
                            <div class="input text">
                                <label>Category Description</label>
                                <textarea name="category_description" class="form-control" type="text" id="category_description" ><?php echo $res->category_description ;?></textarea>
                            </div>
                        </div>
                         <div class="form-group col-md-6">
                            <div class="input text">
                                <label>Category Image</label>
                                <input type="file" name="category_img" ><br>
                                  <?php echo "<img src='$res->category_img_path$res->category_img' width='80' />";?>  
                            </div>
                        </div>                      
                    </div>

                    <div class="row">                        
                        <div class="form-group col-md-6">
                            <div class="input text">
                                <label>Specificatin</label><br>
                                <span id="spcification_id">
                                <?php
                               // print_r($category_specification_list);die;
                                  foreach ($specification_list as $s_list)
                                  {
                                    if($s_list->specification_type == $res->category_type) { ?>
                                    <input type="checkbox" name="specificatin_value[]" value="<?php echo $s_list->specification_id; ?>" <?php  foreach ($category_specification_list as $cs_list)
                                  { if($cs_list->specification_id == $s_list->specification_id){
                                    ?> checked <?php
                                    } 
                                    }?> >&nbsp; <?php echo $s_list->specification_name ;?>&nbsp;&nbsp;
                                       <?php
                                        } 
                                   }
                                 ?>
                                </span>
                               
                                <?php echo form_error('specificatin_value[]','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>
                    </div>
                   
                </div>
                <!-- /.box-body -->      
                <div class="box-footer">
                    <button class="btn btn-success btn-sm" type="submit" name="Submit" value="Edit" >Update</button>
                    <a class="btn btn-danger btn-sm" href="<?php echo base_url() ;?>admin/category">Cancel</a>
                </div>
                <?php
              }
                ?>
            </form>
        </div>
        <!-- /.box -->
    </section>
    <!-- /.content -->
</aside>
<!-- /.right-side -->
