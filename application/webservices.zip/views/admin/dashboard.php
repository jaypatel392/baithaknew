<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>	
			Welcome	<small>Control panel</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li class="active">Welcome</li>
        </ol>
    </section>
    <div>
        <div id="msg_div">
            <?php echo $this->session->flashdata('message');?>
        </div>
    </div>
    <!-- Main content -->
    <section class="content">
        <h1>Welcome To <?php echo $this->user; ?></h1>
        <!--<?php print_r($session);?>-->
    </section>
    <!-- /.content -->
</aside>
<!-- /.right-side -->