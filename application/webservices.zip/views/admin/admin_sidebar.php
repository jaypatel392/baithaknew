<!-- Left side column. contains the logo and sidebar -->
<aside class="left-side sidebar-offcanvas">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
        <!-- Sidebar user panel -->
        <div class="user-panel">
            <div class="pull-left image">
                <img src="<?php echo base_url();?>webroot/admin/img/avatar3.png" class="img-circle" alt="User Image" />
            </div>
			<div class="pull-left info">
				<p>Hello, 
					<?php echo $this->user;?>
				</p>
			</div>
            </div>
          
            <!-- sidebar menu: : style can be found in sidebar.less -->
            <ul class="sidebar-menu">
                <!--********************	Show Dashboard Tab First ********************-->
                <?php 
                    foreach ($getAllTabAsPerRole as $value) {
                        ?>
                        <li class="<?php echo ($this->uri->segment(2)== $value->controller_name)?'active':''?>">
                            <a href="<?php echo base_url(); ?>admin/<?php echo $value->controller_name; ?>">
                                <i class="fa fa-dashboard"></i>
                                <span><?php echo $value->tabname; ?></span>
                            </a>
                        </li>
                        <?php
                    }
                ?>                
				<br/><br/><br/><br/>
            </ul>
        </section>
        <!-- /.sidebar -->
    </aside>