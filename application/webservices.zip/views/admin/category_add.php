<aside class="right-side">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>	
			Category<small>Control panel</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo base_url();?>admin/dashboard"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="<?php echo base_url();?>admin/category">Category</a></li>
            <li class="active">Category Add</li>
        </ol>
    </section>
    <div>
        <div id="msg_div">
            <?php echo $this->session->flashdata('message');?>
        </div>
    </div>
    <!-- Main content -->
    <section class="content">       
        <div class="box">
            <div class="box-header">
                <div class="pull-left">
                    <h3 class="box-title">Category Add</h3>
                </div>
                <div class="pull-right box-tools">
                    <a href="<?php echo base_url();?>admin/category" class="btn btn-info btn-sm">Back</a>                           
                </div>
            </div>
            <form action="" method="post" accept-charset="utf-8" enctype="multipart/form-data">
                <!-- /.box-header -->
                <div class="box-body">
                    <div class="row">
                        <div class="form-group col-md-6">
                            <div class="input text">
                                <label>Category Name<span class="text-danger">*</span></label>
                                <input name="category_name" class="form-control" type="text" id="category_name" value="<?php echo set_value('category_name'); ?>" />
                                <?php echo form_error('category_name','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>
                        <div class="form-group col-md-6">
                            <div class="input text">
                                <label>Category Type</label>
                                <select name="category_type" id="category_type" class="form-control" onchange="getParentCategory(this.value);">
                                    <option value=""></option>
                                    <option value="Event">Event</option>
                                    <option value="Product">Product</option>
                                </select>
                               
                            </div>
                        </div>                      
                    </div>
                    <div class="row">
                        <div class="form-group col-md-6">
                            <div class="input text">
                                <label>Parent Category</label>
                                <select name="category_parent_id" id="category_parent_id" class="form-control">
                                <option value=""></option>
                                 </select>
                            </div>
                        </div>  
                        <div class="form-group col-md-6">
                            <div class="input text">
                                <label>Category Status</label>
                                <select name="category_status" id="category_status" class="form-control">                                   
                                    <option value="1">Active</option>
                                    <option value="0">Deactive</option>
                                </select>
                            </div>
                        </div>                        
                    </div>
                    <div class="row">
                        <div class="form-group col-md-6">
                            <div class="input text">
                                <label>Category Description</label>
                                <textarea name="category_description" class="form-control" type="text" id="category_description" ><?php echo set_value('category_description'); ?></textarea>
                            </div>
                        </div>
                         <div class="form-group col-md-6">
                            <div class="input text">
                                <label>Category Image</label>
                                <input type="file" name="category_img" >
                               
                            </div>
                        </div>
                    </div>
                    <div class="row">                        
                        <div class="form-group col-md-6">
                            <div class="input text">
                                <label>Specificatin</label><br>
                                <span id="spcification_id"></span>
                               
                                <?php echo form_error('specificatin_value[]','<span class="text-danger">','</span>'); ?>
                            </div>
                        </div>
                    </div>
                   
                </div>
                <!-- /.box-body -->      
                <div class="box-footer">
                    <button class="btn btn-success btn-sm" type="submit" name="Submit" value="Add" >Submit</button>
                    <a class="btn btn-danger btn-sm" href="<?php echo base_url() ;?>admin/category">Cancel</a>
                </div>
            </form>
        </div>
        <!-- /.box -->
    </section>
    <!-- /.content -->
</aside>
<!-- /.right-side -->
<script type="text/javascript">
    function getParentCategory(category_type)
    {
         
        var str = 'category_type='+category_type;
        var PAGE = '<?php echo base_url(); ?>admin/category/getParentCategory';
        
        jQuery.ajax({
            type :"POST",
            url  :PAGE,
            data : str,
            success:function(data)
            { 
                 
                var str = 'specification_type='+category_type;
                var PAGE = '<?php echo base_url(); ?>admin/category/getSpecificationBytype';
                
                 jQuery.ajax({
                    type :"POST",
                    url  :PAGE,
                    data : str,
                    success:function(data1)
                    {                           
                     $('#spcification_id').html(data1);
                    } 
                }); 

                if(data != "")
                {
                    $('#category_parent_id').html(data);

                }
                else
                {
                    $('#category_parent_id').html('<option value=""></option>');
                   
                }
            } 
        });
    }
  
  

</script>