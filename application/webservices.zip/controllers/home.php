<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Home extends MY_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('front/homepage_model');
	}
	
	public function index()
	{

	   $this->data['categories'] = $this->homepage_model->getAllcategories();	  
	   $this->data['newProduct'] = $this->homepage_model->getNewProduct();
	   $this->data['brands'] = $this->homepage_model->getBrands();
	   $this->data['three_products_latest'] = $this->homepage_model->getThreeProductLatest();  
	   
	    $this->data['discountedProduct'] = $this->homepage_model->getDiscountedProduct();
	    // echo "<pre>";
	    // print_r($this->data['discount_list']); die; 
 
	   $this->show_view_front('front/home',$this->data);
		
    }

    public function ThreeProductByCategoryId()
    {
       $category_id = $this->input->post('category_id');
       $three_products_details = $this->homepage_model->getThreeProductByCategoryId($category_id);
     
       $html = '';
       foreach ($three_products_details as $tp_value) {
			 $html .= '<div class="col-md-4 agile_ecommerce_tab_left"><div class="hs-wrapper">';
			   $three_products_img = $this->homepage_model->getThreeProductImage($tp_value->product_id);
			 
				 foreach ($three_products_img as $tp_img_value) {
				   $html .='<img src="'.$tp_img_value->product_img_name.'?>" alt=" " class="img-responsive" />';
			    }
				$html .='<div class="w3_hs_bottom"><ul><li><a href="'.base_url().'singleproduct/viewProductDetail/'.$tp_value->product_id.'"><span class="glyphicon glyphicon-eye-open" aria-hidden="true"></span></a></li></ul></div></div><h5><a href="'.base_url().'singleproduct/viewProductDetail/'.$tp_value->product_id.'">'.$tp_value->product_title.'</a></h5><div class="simpleCart_shelfItem"><p><i class="item_price">Rs '.$tp_value->product_sale_price.'</i></p>';
					   $cart_details = $this->cart->contents();
					   $check_cart=0;
					    foreach ($cart_details as $cart_value) {
					      if($cart_value['id'] == $tp_value->product_id){
					        $check_cart++;
					       }
					     }
					   if($check_cart){
					   
					 		$html .= '<a href="'.base_url().'products/viewCart"><button type="button" class="w3ls-cart">Go to cart</button></a></div></div>';
					   }else{
					  
					 		 $html .= '<div id="add_crt_btn'.$tp_value->product_id.'"><button type="button" onclick="productAddToCart('.$tp_value->product_id.')" class="w3ls-cart">Add to cart</button></div></div></div>';
					  	}
         }
         echo $html;
    }    
}

/* End of file */
?>