<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Userlogin extends MY_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('front/userlogin_model');	
	}

	/* Login */
	public function user_registration()
	{
		          $post['user_name'] = $this->input->post('user_name');
		          $post['user_email'] = $this->input->post('user_ragister_email');
			  $post['user_password'] = $this->input->post('user_Rpassword');
			  $post['user_created_date'] = date('Y-m-d');
			  $post['user_updated_date'] = date('Y-m-d');
			  $post['user_type'] = 'n_user';			 
			  $post['user_status'] = 1;			 
			  $user_details = $this->userlogin_model->user_registration($post);

			    if(!empty($user_details))
			    {						
				   echo '1';
				}else{
					echo "";
				}				
		
	}

	function checkUserEmailId(){

		   $user_email = $this->input->post('user_ragister_email');
  		   $check_user = $this->userlogin_model->checkUserEmailId($user_email);	  
                    //print_r($check_user); die;
			    if(empty($check_user))
			    {						
				   echo "0";

				}else{

					echo "1";

				}
	}

	function checkUserLogin(){ 
		          
		                        $data['user_email'] = $this->input->post('user_email');
					$data['user_password'] = $this->input->post('user_password');
                                        // print_r($data); die;
					$user_details = $this->userlogin_model->checkUserLogin($data);
				

					if(!empty($user_details))
					{
						$this->session->set_userdata($user_details);
						echo "1";
					}else{
						echo "";
					}
	}

	/*	Logout */
	public function logout() 
	{        
        $this->session->sess_destroy();		
        redirect(base_url());
    }
				
}
?>