<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Product extends MY_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('admin/product_model');
	}
	
	/* Details */
	public function index()
	{
		if($this->checkViewPermission())
		{			
			$this->data['product_result'] = $this->product_model->getAllProduct();             
			$this->show_view_admin('admin/product', $this->data);
		}
		else
		{	
			redirect( base_url().'admin/dashboard/error/1');
		}
    }


    /* Add and Update */
	public function addProduct()
	{
		$product_id = $this->uri->segment(4);
		if($product_id)
		{
			if($this->checkEditPermission())
			{
				if (isset($_POST['Submit']) && $_POST['Submit'] == "Edit") 
				{
					
					$this->form_validation->set_rules($this->validation_rules['productUpdate']);
					if($this->form_validation->run())
					{
						$post['product_id'] = $product_id;
						$post['product_name'] = $this->input->post('product_name');
						$post['product_type'] = $this->input->post('product_type');
						$post['product_multiply_type'] = $this->input->post('product_multiply_type');
						$post['product_multiply_value'] = $this->input->post('product_multiply_value');
						$post['product_value'] = $this->input->post('product_value');
						$post['product_status'] = $this->input->post('product_status');						
						$post['product_updated_date'] = date('Y-m-d');
						$this->product_model->updateproduct($post);

						$msg = 'product update successfully!!';					
						$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
						redirect(base_url().'admin/product');
					}
					else
					{
						$this->data['product_edit'] = $this->product_model->editproduct($product_id);
						$this->show_view_admin('admin/product_update', $this->data);
					}
				}
				else
				{
					$this->data['product_edit'] = $this->product_model->editproduct($product_id);
						$this->show_view_admin('admin/product_update', $this->data);
				}
			}
			else
			{
				redirect( base_url().'admin/dashboard/error/1');
			}
		}
		else
		{
			if($this->checkAddPermission())
			{				
				if (isset($_POST['Submit']) && $_POST['Submit'] == "Add") 
				{
				
				
						$post['product_uid'] = time();
						$post['product_title'] = $this->input->post('product_title');
						$post['product_description'] = $this->input->post('product_description');
						$post['product_category_id'] = $this->input->post('product_category_id');
						$post['product_parent_cat_id'] = $this->input->post('product_parent_cat_id');
						$post['product_shipping_id'] = $this->input->post('product_shipping_id');
						$post['product_discount_id'] = $this->input->post('product_discount_id');
						$post['product_tax_id'] = $this->input->post('product_tax_id');
						$post['product_purchase_price'] = $this->input->post('product_purchase_price');
						$post['product_sale_price'] = $this->input->post('product_sale_price');
						$post['product_brand_id'] = $this->input->post('product_brand_id');
						$post['product_currency_type'] = $this->input->post('product_currency_type');
						$post['product_qty'] = $this->input->post('product_qty');
						$post['product_moq'] = $this->input->post('product_moq');
						$post['product_status'] = $this->input->post('product_status');			
						$post['product_created_date'] = date('Y-m-d');
						$post['product_updated_date'] = date('Y-m-d');
						$post['added_by'] = $this->data['user_id'];
						 if ($_FILES["product_thumb_img"]["name"]) {
			                            $product_thumb_img    = 'product_thumb_img';
			                            $fieldName            = "product_thumb_img";
			                            $Path                 = 'webroot/admin/upload/product/';
			                            $product_thumb_img = $this->ImageUpload($_FILES["product_thumb_img"]["name"], $product_thumb_img, $Path, $fieldName);
			                            $post['product_thumb_img'] = base_url().''.$Path.''.$product_thumb_img;
			                          
			                        }
						$product_id =  $this->product_model->addProduct($post);

						if($product_id)
						{
						
							$product_images = $_FILES["product_images"]['name'];
							//print_r($product_images); die;
				                         for($i = 0; $i < count($product_images); $i++)
							  {						  
					                    $imagedetails = getimagesize($_FILES["product_images"]['tmp_name'][$i]);
				       			   $width = $imagedetails[0];
				                           $height = $imagedetails[1];
				                            if($width > 600 && $height > 400)
				                            {
			                            	
				                            	$image_name = $_FILES["product_images"]["name"][$i];
					                            $Path = 'webroot/admin/upload/product/';
					                            move_uploaded_file($_FILES['product_images']['tmp_name'][$i],$Path);
					                            $product_imgs['product_img_name'] = base_url().''.$Path.''.$image_name;
					                            $product_imgs['product_id'] = $product_id;
					                            $product_imgs['product_img_created_date'] = date('Y-m-d');
					                            $product_imgs['product_img_updated_date'] = date('Y-m-d');
					                            $product_imgs['added_by'] = $this->data['user_id'];
					                            $imgs_res = $this->product_model->addProductImags($product_imgs);
			
			                                   }
			
			                               }
			                               if(!empty($this->input->post('attr_counter'))){	
							$attr_counter= $this->input->post('attr_counter');
			                                $attribute_name = $this->input->post('attribute_name');
			                                 $attr_value = $this->input->post('attr_value');
				                        $j = 0;
				                        $a = 0;
				                        $product_id = $product_id;
			
						        for($i = 0; $i < count($attribute_name); $i++)
				                        {
				                         	//$a = $j + $timing_counter[$i];
				                         	//echo "aaa---".$a.'<br>';
				                         	$attr['attr_name'] = $attribute_name[$i];
				                         	$attr['product_id'] = $product_id;
				                         	$attr['added_by'] = $this->data['user_id'];
				                         	$attr_id =  $this->product_model->addProductAttr($attr);
				                         	for($j = $a; $j < ($attr_counter[$i]*2+$a);)
				                         	{
				                         		$attr_val['attr_id']= $attr_id;
				                         		$attr_val['attr_value']= $attr_value[$j];
				                         		$attr_val['attr_price']= $attr_value[$j+1];
				                         		
				                         		$res =  $this->product_model->addProductAttrVal($attr_val);
				                         		$j= $j+2;
				                         	}
				                           $a = $j;
				                        }
				                        
				                        }
				                        
				                        if(!empty($this->input->post('specification'))){		
				                        $specification = $this->input->post('specification');                 
				                        if($specification)
				                        {
					                        for($i = 0; $i < count($specification);)
					                        {
					                        	$p_spc['product_id'] = $product_id;
					                         	$p_spc['specification_id'] = $specification[$i];
					                         	$p_spc['specification_val_id']= $specification[$i+1];
					                         	$this->product_model->addProductSpecification($p_spc);
					                         	$i = $i+2;
					                        }
					                    }
					                    
					                  }

		                 

							$msg = 'product added successfully!!';					
							$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
							redirect(base_url().'admin/product');
						}
						else
						{
							$msg = 'Whoops, looks like something went wrong!';					
							$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-danger alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
							redirect(base_url().'admin/product/addProduct');
						}
						
				}else{
                    $this->data['shipping_list'] = $this->product_model->getShippingList();
					$this->data['tax_list'] = $this->product_model->getTaxList();	
					$this->data['category_list'] = $this->product_model->getCategoryList();    
					$this->data['discount_list'] = $this->product_model->getDiscountList();                  
					$this->data['brand_list'] = $this->product_model->getBrandList();    
					$this->show_view_admin('admin/product_add', $this->data);
				}
			}
			else
			{
				redirect( base_url().'admin/dashboard/error/1');
			}
		}
	}

/* Get State List */
	public function getSubCategoryList()
	{
		$category_id = $this->input->post('category_id');
		$sub_category_list = $this->product_model->getSubCategoryList($category_id);
       
		$html = '';
		if(count($sub_category_list) > 0)
		{
			$html .=  '<option value=""></option>'; 
			foreach ($sub_category_list as $sub_list) 
			{
				$html .= '<option value="'.$sub_list->category_id.'">'.$sub_list->category_name.'</option>';
			}
			
			echo $html; 
		}
		else
		{
			echo $html;
		}
	}

/* Get State List */
	public function getAllSpecification()
	{

		$category_id = $this->input->post('category_id');
		$specification_list = $this->product_model->getAllSpecification($category_id);
       	$html = '';
		if(count($specification_list) > 0)
		{
			
			foreach ($specification_list as $spc_list) 
			{
				$html .= '<div class="row"><div class="col-md-2"><div class="input text"><br><input type="checkbox" value="'.$spc_list->specification_id.'" name="specification[]" onclick="GetAllSpecificationVal('.$spc_list->specification_id.')" id="check_or_not'.$spc_list->specification_id.'" >'.'&nbsp'.$spc_list->specification_name.'</div></div><div id="allspcifictionVal'.$spc_list->specification_id.'"></div></div>';
			}
			$html .= "<br>";
			echo $html; 
		}
		else
		{
			echo $html;
		}
	}


/* Get State List */
	public function getAllSpecificationVal()
	{
		$specification_id = $this->input->post('specification_id');
		$specification_val_list = $this->product_model->getAllSpecificationVal($specification_id);
       	$html = '';
		if(count($specification_val_list) > 0)
		{
			
			$html .=  '<div id="remove_sp_val'.$specification_id.'"><div class="col-md-2"><lable>&nbsp;</lable><select class="form-control" name="specification[]"><option value="" required >Select Specification Value</option>'; 
			foreach ($specification_val_list as $s_val_list) 
			{
				$html .= '<option value="'.$s_val_list->specification_val_id.'">'.$s_val_list->specification_val.'</option>';
			}
			$html .="</select></div>";
			echo $html; 
		}
		else
		{
			echo $html;
		}
	}


	/* Delete */
	public function delete_product()
	{
		if($this->checkDeletePermission())
		{
			$product_id = $this->uri->segment(4);
			
			$this->product_model->delete_product($product_id);
			if ($this->db->_error_number() == 1451)
			{		
				$msg = 'You need to delete child category first';
				$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-danger alert-dismissable"><i class="fa fa-ban"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
				redirect(base_url().'admin/product'); 
			}
			else
			{
				$msg = 'product remove successfully...!';					
				$this->session->set_flashdata('message', '<section class="content"><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
				redirect(base_url().'admin/product');
			}
		}
		else
		{
			redirect( base_url().'admin/dashboard/error/1');
		}		
	}	
}

/* End of file */?>