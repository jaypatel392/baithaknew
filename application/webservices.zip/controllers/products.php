<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Products extends MY_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('front/products_model');
                 
	}
	
	public function productsBycategories()
	{
		$cat_id = $this->uri->segment(3);
	   	$this->data['categories'] = $this->products_model->getAllcategories();
	   	$this->data['productsBycat'] = $this->products_model->getProductByCategoryId($cat_id);
		$this->show_view_front('front/products',$this->data);		

		
    }

    public function getProductsByCatId()
	{
		$cat_id = $this->input->post('cat_id');
		$products = $this->products_model->getProductByCategoryId($cat_id);
		//print_r($products); die;
			$html ='';			
			if(sizeof($products) > 0){
			$html .= '<div class="w3ls_mobiles_grid_right_grid3">';
			foreach ($products as $value) {
				$html .='<div class="col-md-4 agileinfo_new_products_grid agileinfo_new_products_grid_mobiles"><div class="agile_ecommerce_tab_left mobiles_grid"><div class="hs-wrapper hs-wrapper2">';
				 $products_imgs =  $this->products_model->getThreeProductImage($value->product_id);
				foreach ($products_imgs as $valueImg) { 
				$html .='<img src="'.$valueImg->product_img_name.'" alt=" " class="img-responsive" />';
				} 
				$html .= '<div class="w3_hs_bottom w3_hs_bottom_sub1"><ul><li><a href="#" data-toggle="modal" data-target="#myModal9"><span class="glyphicon glyphicon-eye-open" aria-hidden="true"></span></a></li></ul></div></div><h5><a href="'.base_url().'singleproduct/viewProductDetail/'.$value->product_id.'">'.$value->product_title.'</a></h5> <div class="simpleCart_shelfItem"><p><i class="item_price">Rs '.$value->product_sale_price.'</i></p>';
												  
				$cart_details = $this->cart->contents();
				$check_cart=0;
				foreach ($cart_details as $cart_value) {
				if($cart_value['id'] == $value->product_id){
				$check_cart++;
				}
				}
				if($check_cart){
				
				$html .= '<a href="<?php echo base_url();?>products/viewCart"><button type="button" class="w3ls-cart">Go to cart</button></a>';
				}else{
			
				$html .= '<a href= "'.base_url().'singleproduct/viewProductDetail/'.$value->product_id.';?>" ><button type="button" class="w3ls-cart">Add to cart</button></a>';
				
				}
								

				$html .= '</div></div></div>';

			}
			 echo $html;
		   }else{
			 echo $html;
		   }
		}

  public function getProductsByCatIdAndPrice(){

          $cat_id = $this->input->post('cat_id');
          $min_price = $this->input->post('min_price');
          $max_price = $this->input->post('max_price');
          $products = $this->products_model->getProductByCategoryIdAndPrice($cat_id,$min_price,$max_price);
		$html ='';
		if(!empty($products)){
		$html .= '<div class="w3ls_mobiles_grid_right_grid3">';
   	        foreach ($products as $value) {
			$html .='<div class="col-md-4 agileinfo_new_products_grid agileinfo_new_products_grid_mobiles"><div class="agile_ecommerce_tab_left mobiles_grid"><div class="hs-wrapper hs-wrapper2">';
				 $products_imgs =  $this->products_model->getThreeProductImage($value->product_id);
				foreach ($products_imgs as $valueImg) { 
				$html .='<img src="'.$valueImg->product_img_name.'" alt=" " class="img-responsive" />';
				} 
				$html .= '<div class="w3_hs_bottom w3_hs_bottom_sub1"><ul><li><a href="#" data-toggle="modal" data-target="#myModal9"><span class="glyphicon glyphicon-eye-open" aria-hidden="true"></span></a></li></ul></div></div><h5><a href="'.base_url().'singleproduct/viewProductDetail/'.$value->product_id.'">'.$value->product_title.'</a></h5> <div class="simpleCart_shelfItem"><p><i class="item_price">Rs '.$value->product_sale_price.'</i></p>';
												  
				$cart_details = $this->cart->contents();
				$check_cart=0;
				foreach ($cart_details as $cart_value) {
				if($cart_value['id'] == $value->product_id){
				$check_cart++;
				}
				}
				if($check_cart){
				
				$html .= '<a href="<?php echo base_url();?>products/viewCart"><button type="button" class="w3ls-cart">Go to cart</button></a>';
				}else{
			
				$html .= '<a href= "'.base_url().'singleproduct/viewProductDetail/'.$value->product_id.'" ><button type="button" class="w3ls-cart">Add to cart</button></a>';
				
				}
								

				$html .= '</div></div></div>';
			}
				
				$html .= '<input type ="hidden" id ="hiddenCategory" value ="'.$cat_id.'"><div class="clearfix"> </div>
			</div>';
			 echo $html;
		}else{
		echo $html;
	}


}


public function getsortedProducts(){
	//print_r($_POST);die();
	$sortBy = $this->input->post('sortingBy');
	$cat_id = $this->input->post('cat_id');
	$products = $this->products_model->getSortedProduct($cat_id,$sortBy);
		$html ='';
		if(!empty($products)){
		$html .= '<div class="w3ls_mobiles_grid_right_grid3">';
   	        foreach ($products as $value) {
			$html .='<div class="col-md-4 agileinfo_new_products_grid agileinfo_new_products_grid_mobiles"><div class="agile_ecommerce_tab_left mobiles_grid"><div class="hs-wrapper hs-wrapper2">';
				 $products_imgs =  $this->products_model->getThreeProductImage($value->product_id);
				foreach ($products_imgs as $valueImg) { 
				$html .='<img src="'.$valueImg->product_img_name.'" alt=" " class="img-responsive" />';
				} 
				$html .= '<div class="w3_hs_bottom w3_hs_bottom_sub1"><ul><li><a href="#" data-toggle="modal" data-target="#myModal9"><span class="glyphicon glyphicon-eye-open" aria-hidden="true"></span></a></li></ul></div></div><h5><a href="'.base_url().'singleproduct/viewProductDetail/'.$value->product_id.'">'.$value->product_title.'</a></h5> <div class="simpleCart_shelfItem"><p><i class="item_price">Rs '.$value->product_sale_price.'</i></p>';
												  
				$cart_details = $this->cart->contents();
				$check_cart=0;
				foreach ($cart_details as $cart_value) {
				if($cart_value['id'] == $value->product_id){
				$check_cart++;
				}
				}
				if($check_cart){
				
				$html .= '<a href="<?php echo base_url();?>products/viewCart"><button type="button" class="w3ls-cart">Go to cart</button></a>';
				}else{
			
				$html .= '<a href= "'.base_url().'singleproduct/viewProductDetail/'.$value->product_id.';?>" ><button type="button" class="w3ls-cart">Add to cart</button></a>';
				
				}
								

				$html .= '</div></div></div>';
			}
				
				$html .= '<input type ="hidden" id ="hiddenCategory" value ="'.$cat_id.'"><div class="clearfix"> </div>
			</div>';
			 echo $html;
		}else{
		echo $html;
	}
	}


	public function viewCart(){

		if(isset($_POST['checkout'])){ 

				$cart_product_list = $this->cart->contents();
				$session = $this->session->all_userdata(); 
				// echo "<pre>";
				// print_r($cart_product_list); die;   
				foreach ($cart_product_list as $cart_res) {

					$post['cart_product_id'] = $cart_res['id'];
					$post['cart_user_id'] = $session[0]->user_id;
					$post['cart_product_qty'] = $cart_res['qty'];
					$post['cart_discount_price'] = $cart_res['price'];
					$post['cart_total_price'] = $this->cart->total();
					$post['cart_created_date'] = date('Y-m-d');					
					$add_cart_res = $this->products_model->addCartproducts($post);
					if($add_cart_res){

						if(!empty($cart_res['attr'])){

							$a = explode(',', $cart_res['attr']);

							for ($i=0; $i < count($a); $i++) {
								$b = explode('_', $a[$i]);
								$attr_post['cart_id'] = $add_cart_res;          	
								$attr_post['cart_product_attr_id'] = $b[0];          	
								$attr_post['cart_product_attr_val_name'] = $b[1];
								$attr_post['cart_product_id'] =  $cart_res['id'];       	
								$attr_post['cart_attr_user_id'] = $session[0]->user_id;
								$add_cart_attr_res = $this->products_model->addCartproductsAttr($attr_post);  

						    }
						  }
					}

				}
				if($add_cart_res){
				  redirect(base_url().'products/userAddressDetails');				
				}   
		}else{

			$this->data['cart_list'] = $this->cart->contents();
			$this->show_view_front('front/viewcart',$this->data);
		}

	}
       public function removeCartItem(){
      	$cart_id = $this->input->post('cart_id');
      	$data = array(
				'rowid'   => $cart_id,
				'qty'     => 0
			);

			echo $removeres =$this->cart->update($data);
      }

      public function updateCartProductqty(){

      	$cart_id = $this->input->post('cart_id');
      	$qty_value = $this->input->post('qty_value');
      	$data = array(
				'rowid'   => $cart_id,
				'qty'     => $qty_value
			);
      	 echo $update_qty =$this->cart->update($data);
      }
      
      public function userAddressDetails(){

      	    $session = $this->session->all_userdata();       		
      		if(isset($_POST['confirm'])){
      			echo "<pre>";
      			print_r($_POST); die;

      		}else{


      			$this->data['user_details'] = $this->products_model->getUserDetailsById($session[0]->user_id);
      			$this->data['country_list'] = $this->products_model->getCountryList();

      			$this->show_view_front('front/user_address_details' , $this->data);

      		}
      }

      /* Get State List */
	public function getStateList()
	{
		$country_id = $this->input->post('country_id');
		$state_list = $this->products_model->getStateListByCountryId($country_id);

		$html = '';
		if(count($state_list) > 0)
		{
			foreach ($state_list as $s_list) 
			{
				$html .= '<option value="'.$s_list->state_id.'">'.$s_list->state_name.'</option>';
			}
			
			echo $html; 
		}
		else
		{
			echo $html;
		}
	}

     public function searchProductByBrand()
	{
		$brand_id = $this->uri->segment(3);
	 	  	$this->data['productsBybrand'] = $this->products_model->getProductBybrandId($brand_id);
	 	$this->data['brands'] = $this->products_model->getAllbrands();
	 	  	//echo '<pre>';
	   	//print_r($this->data['productsBybrand']);die();
		$this->show_view_front('front/productsBybrand',$this->data);
		

		
    }


   public function getProductsByBrandIdAndPrice()
		{
		//print_r($_POST);die();
		$brand_id = $this->input->post('brand_id');
		$min_price = $this->input->post('min_price');
		$max_price = $this->input->post('max_price');
		$products = $this->products_model->getProductByBrandIdAndPrice($brand_id,$min_price,$max_price);		
		$html ='';
	    if(!empty($products)){
			$html .= '<div class="w3ls_mobiles_grid_right_grid3">';
	   	        foreach ($products as $value) {
					$html .='<div class="col-md-4 agileinfo_new_products_grid agileinfo_new_products_grid_mobiles"><div class="agile_ecommerce_tab_left mobiles_grid"><div class="hs-wrapper hs-wrapper2">';
						 $products_imgs =  $this->products_model->getThreeProductImage($value->product_id);
						foreach ($products_imgs as $valueImg) { 
						$html .='<img src="'.$valueImg->product_img_name.'" alt=" " class="img-responsive" />';
						} 
						$html .= '<div class="w3_hs_bottom w3_hs_bottom_sub1"><ul><li><a href="#" data-toggle="modal" data-target="#myModal9"><span class="glyphicon glyphicon-eye-open" aria-hidden="true"></span></a></li></ul></div></div><h5><a href="'.base_url().'singleproduct/viewProductDetail/'.$value->product_id.'">'.$value->product_title.'</a></h5> <div class="simpleCart_shelfItem"><p><i class="item_price">Rs '.$value->product_sale_price.'</i></p>';
														  
						$cart_details = $this->cart->contents();
						$check_cart=0;
						foreach ($cart_details as $cart_value) {
						if($cart_value['id'] == $value->product_id){
						$check_cart++;
						}
						}
						if($check_cart){
						
						$html .= '<a href="<?php echo base_url();?>products/viewCart"><button type="button" class="w3ls-cart">Go to cart</button></a>';
						}else{
					
						$html .= '<a href= "'.base_url().'singleproduct/viewProductDetail/'.$value->product_id.';?>" ><button type="button" class="w3ls-cart">Add to cart</button></a>';
						
						}
										

						$html .= '</div></div></div>';
				}
					
					$html .= '<div class="clearfix"> </div>
				</div>';
				 echo $html;
			}else{
			echo $html;
		}
	}



public function getsortedProductsbyBrand(){
	
	$sortBy = $this->input->post('sortingBy');
	$brand_id = $this->input->post('brand_id');
	$products = $this->products_model->getsortedProductsbyBrand($brand_id,$sortBy);
		$html ='';
		
			 if(!empty($products)){
			$html .= '<div class="w3ls_mobiles_grid_right_grid3">';
	   	        foreach ($products as $value) {
					$html .='<div class="col-md-4 agileinfo_new_products_grid agileinfo_new_products_grid_mobiles"><div class="agile_ecommerce_tab_left mobiles_grid"><div class="hs-wrapper hs-wrapper2">';
						 $products_imgs =  $this->products_model->getThreeProductImage($value->product_id);
						foreach ($products_imgs as $valueImg) { 
						$html .='<img src="'.$valueImg->product_img_name.'" alt=" " class="img-responsive" />';
						} 
						$html .= '<div class="w3_hs_bottom w3_hs_bottom_sub1"><ul><li><a href="#" data-toggle="modal" data-target="#myModal9"><span class="glyphicon glyphicon-eye-open" aria-hidden="true"></span></a></li></ul></div></div><h5><a href="'.base_url().'singleproduct/viewProductDetail/'.$value->product_id.'">'.$value->product_title.'</a></h5> <div class="simpleCart_shelfItem"><p><i class="item_price">Rs '.$value->product_sale_price.'</i></p>';
														  
						$cart_details = $this->cart->contents();
						$check_cart=0;
						foreach ($cart_details as $cart_value) {
						if($cart_value['id'] == $value->product_id){
						$check_cart++;
						}
						}
						if($check_cart){
						
						$html .= '<a href="<?php echo base_url();?>products/viewCart"><button type="button" class="w3ls-cart">Go to cart</button></a>';
						}else{
					
						$html .= '<a href= "'.base_url().'singleproduct/viewProductDetail/'.$value->product_id.';?>" ><button type="button" class="w3ls-cart">Add to cart</button></a>';
						
						}
										

						$html .= '</div></div></div>';
				}
					
					$html .= '<div class="clearfix"> </div>
				</div>';
				 echo $html;
			}else{
			echo $html;
		}
     }
    
   }

/* End of file */
?>