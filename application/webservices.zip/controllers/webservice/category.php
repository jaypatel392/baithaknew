<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Category extends MY_Controller 
{
	function __construct()
	{
		parent::__construct();
		$this->load->model('webservice/category_model');	
	}
	
	public function parentCategory()
	{
		$category_list = $this->category_model->getParentCategory();
		if(!empty($category_list))
		{
			echo json_encode(array("status"=>1,"category_list"=>$category_list));
		}
		else
		{
			echo json_encode(array("status"=>0));
		}
	} 		
	public function productByParentCategoryId()
	{
		$category_id = $_GET['category_id'];
		$sort = @$_GET['sort'];
		$filter = @$_GET['filter'];
		if($sort)
		{
			$product_by_category = $this->category_model->productByParentCategoryIdWithSort($category_id, $sort);			
		}
		elseif($filter == 'Y')
		{			
			$post['brand'] = @$_GET['brand'];
			$post['specification'] = @$_GET['specification'];
			$product_by_category = $this->category_model->productByParentCategoryIdWithFilter($category_id, $post);
			// echo "<pre>";
			// print_r($product_by_category);
			// die();
		}
		elseif($sort && $filter  == 'Y')
		{
			$product_by_category = $this->category_model->productByParentCategoryId($category_id);
		}
		else
		{
			$product_by_category = $this->category_model->productByParentCategoryId($category_id);
		}


		$discount_list = $this->category_model->discountList();
		if(!empty($product_by_category))
		{
			echo json_encode(array("status"=>1,"product_by_category"=>$product_by_category, "discount_list"=>$discount_list));
		}
		else
		{
			echo json_encode(array("status"=>0));
		}
	} 	
	public function productDetailByProductId()
	{
		$product_id = $_GET['product_id'];
		$product_detail = $this->category_model->productDetailByProductId($product_id);
		$product_images = $this->category_model->productImagesByProductId($product_id);
		$discount_list = $this->category_model->discountList();
		$attributes_list = $this->category_model->attributesByProductId($product_id);
       		$attributes_value_list = $this->category_model->attributesValue($product_id);
		
		if(!empty($product_detail))
		{
			echo json_encode(array("status"=>1,"product_detail"=>$product_detail, "product_images"=>$product_images, "discount_list"=>$discount_list, "attributes_list"=>$attributes_list, "attributes_value_list"=>$attributes_value_list));
		}
		else
		{
			echo json_encode(array("status"=>0));
		}
	} 
	public function showAllFilter()
	{
		$category_id = $_GET['category_id'];
		$brand_list = $this->category_model->getBrandList($category_id);
		$specification_list = $this->category_model->getSpecificationByCategory($category_id);
		$specification_value = $this->category_model->getSpecificationValue();
		
		if(!empty($brand_list) && !empty($specification_list))
		{
			echo json_encode(array("status"=>1, "brand_list"=>$brand_list, "specification_list"=>$specification_list, "specification_value"=>$specification_value ));
		}
		else
		{
			echo json_encode(array("status"=>0));
		}
	}
	/************************************ Start Order product **********************************/
	public function orderProduct()
   	{   		

   		$post['order_date_time'] = $_GET['order_date_time'];       
   		$post['order_pay_type'] = $_GET['order_pay_type'];
   		$post['order_tansaction_id'] = $_GET['order_tansaction_id'];       
   		$post['order_payment_status'] = $_GET['order_payment_status'];       
   		$post['order_user_type'] = $_GET['order_user_type'];       
   		$post['order_user_id'] = $_GET['order_user_id'];       
   	    	$post['order_user_d_address_id'] = $_GET['order_user_d_address_id'];       
   		$post['order_user_b_address_id'] = $_GET['order_user_b_address_id'];   
    
   		$order_id = $this->category_model->addOrder($post);

   		$cart_list = $this->category_model->getCartByUserId($post['order_user_id']);
   	
   		foreach ($cart_list as $value)
   		{
   			$p_post['order_id'] = $order_id;
   			$p_post['product_id'] = $value->cart_product_id;
   			$p_post['cart_id'] = $value->cart_id;
   			$order_product_id = $this->category_model->addOrderProduct($p_post);
   			if($order_product_id)
   			{
   				$this->category_model->updateCartStatus($value->cart_id);
   			}
   		}
    		if($order_id)
		{
		  	echo json_encode(array("status"=>1));
		}
		else
		{
			echo json_encode(array("status"=>0));
		}
   	}

   	public function showOrderHistory()
   	{
   		$user_id = $_GET['user_id'];

   		$product_order_history = $this->category_model->getOrderHistory($user_id);
   		$product_order_attr = $this->category_model->getOrderProductAttr($user_id);

   		
    		if($product_order_history)
		{
		  	echo json_encode(array("status"=>1, "product_order_history"=>$product_order_history, "product_order_attr"=>$product_order_attr));
		}
		else
		{
			echo json_encode(array("status"=>0));
		}
   	}

	/************************************ End Order Product **********************************/
	/************************************ Start WISH LIST   ************************************/
	public function addWishList()
	{
		$post['wishlist_user_id'] = $_GET['user_id'];
		$post['wishlist_product_id'] = $_GET['product_id'];
		$post['wishlist_created_date'] = date('Y-m-d');
		$post['wishlist_updated_date'] = date('Y-m-d');
        	$check['wishlist_user_id'] = $_GET['user_id'];
       		$check['wishlist_product_id'] = $_GET['product_id'];
		$check_wish_list = $this->category_model->checkWishList($check);
		
		if(empty($check_wish_list))
		{       
			$add_wish_list = $this->category_model->addWishList($post);
			if(!empty($add_wish_list))
			{
				echo json_encode(array("status"=>1));
			}
			else
			{
				echo json_encode(array("status"=>0));
			}
	  	}
	  	else
	  	{
	  		echo json_encode(array("status"=>2));
	  	}
	} 
	public function getWishList()
	{
		$user_id = $_GET['user_id'];		
       		$discount_list = $this->category_model->discountList();
		$wish_list_details = $this->category_model->getWishListByUserId($user_id);
		
		if(!empty($wish_list_details))
		{
			echo json_encode(array("status"=>1, "wish_list_details"=>$wish_list_details, "discount_list"=>$discount_list));
		}
		else
		{
			echo json_encode(array("status"=>0));
		}
	} 
  	public function deleteWishList()
	{
		$user_id = $_GET['user_id'];
		$wishlist_product_id = $_GET['product_id'];	        
		$delete_wish_list = $this->category_model->deleteWishLitByUserId($user_id,$wishlist_product_id);
		
		if(!empty($delete_wish_list))
		{
			echo json_encode(array("status"=>1));
		}
		else
		{
			echo json_encode(array("status"=>0));
		}
	} 
	/************************************ END WISH LIST   ************************************/
	public function dealProduct()
	{
		$deal_product_list = $this->category_model->dealProductList();
		$discount_list = $this->category_model->discountList();
		if(!empty($deal_product_list) && !empty($discount_list))
		{
			echo json_encode(array("status"=>1,"deal_product_list"=>$deal_product_list,"discount_list"=>$discount_list));
		}
		else
		{
			echo json_encode(array("status"=>0));
		}
	} 
	/************************************* START EVENT ******************************************/
	public function eventCategoryList()
	{		
		$event_category_list = $this->category_model->eventCategoryList();
		if(!empty($event_category_list))
		{
			echo json_encode(array("status"=>1,"event_category_list"=>$event_category_list));
		}
		else
		{
			echo json_encode(array("status"=>0));
		}
	} 
	public function eventListByCategoryId()
	{
		$category_id = $_GET['category_id'];
		$even_list_by_category_id = $this->category_model->eventListByCategoryId($category_id);
		$discount_list = $this->category_model->discountList();
		if(!empty($even_list_by_category_id))
		{
			echo json_encode(array("status"=>1,"even_list_by_category_id"=>$even_list_by_category_id, "discount_list"=>$discount_list));
		}
		else
		{
			echo json_encode(array("status"=>0));
		}
	} 
	public function eventDetailByEventId()
	{
		$event_id = $_GET['event_id'];
		$category_id = $_GET['category_id'];
		$event_detail = $this->category_model->eventDetailByEventId($event_id);
		$discount_list = $this->category_model->discountList();
		$event_date_time_list = $this->category_model->eventDateTime($event_id);
		$event_images = $this->category_model->eventImages($event_id);
		
		$specification_list = $this->category_model->getEventSpecificationList($category_id);
		$specification_value_list = $this->category_model->getEventSpecificationValueList();

		$event_attribute = $this->category_model->eventAttributeList($event_id);
		$event_attribute_value = $this->category_model->eventAttributeValueList();
		
		if(!empty($event_detail))
		{
			echo json_encode(array("status"=>1,"event_detail"=>$event_detail, "discount_list"=>$discount_list, "event_date_time_list"=>$event_date_time_list, "specification_list"=>$specification_list, "specification_value_list"=>$specification_value_list, "event_images"=>$event_images, "event_attribute"=>$event_attribute, "event_attribute_value"=>$event_attribute_value));
		}
		else
		{
			echo json_encode(array("status"=>0));
		}
	}

	/************************************* END EVENT ******************************************/

	/************************************* START CART ******************************************/ 
	public function addCart()
	{
		$post['cart_user_id'] = $_GET['user_id']; 
		$post['cart_product_id'] = $_GET['product_id'];		
		$post['cart_category_id'] = $_GET['category_id'];		     
	        $post['cart_discount_price'] = $_GET['discount_price'];
	        $post['cart_product_qty']= $_GET['cart_product_qty'];
	        $post['cart_total_price']= $_GET['discount_price'] * $_GET['cart_product_qty'];
	        
	        
	        $post['cart_created_date'] =  date('Y-m-d');	
		$check_cart = $this->category_model->checkCart($post);	

		if(empty($check_cart))
		{       
		 	$cart_id = $this->category_model->addCart($post);
		 	if(!empty($cart_id))
			{
			   	if($_GET['attr'])
	           		{
					$attr_json = $_GET['attr'];
					$attr_val = json_decode($attr_json);
	         			foreach ($attr_val as $atr_val) 
	         			{
						$post_attr['cart_product_attr_id'] = $atr_val->attr_id;
						$post_attr['cart_product_attr_val_name'] = $atr_val->attr_name; 
						$post_attr['cart_attr_user_id'] = $_GET['user_id']; 
						$post_attr['cart_product_id'] = $_GET['product_id'];	 
						$post_attr['cart_id'] = $cart_id;	 
						$res = $this->category_model->addCartAttr($post_attr);               
	         			}         		
			  	}
				echo json_encode(array("status"=>1));
			}
			else
			{

				echo json_encode(array("status"=>0));
			}

	 	}
	 	else
	 	{	
	 		$post['cart_user_id'] = $_GET['user_id'];
			$post['cart_product_id'] = $_GET['product_id'];
	        	$post['cart_product_qty'] = $_GET['cart_product_qty'];
	        	$total_price = $_GET['cart_total_price'];        
			$post['cart_total_price']= $post['cart_product_qty'] * $total_price;		
	        	$update_cart_list = $this->category_model->updateCartQty($post);		
	  		echo json_encode(array("status"=>2));
	  	}
  	}   
   	public function getCartList()
	{		
		$user_id = $_GET['user_id'];
		$cart_details = $this->category_model->getCartByUserId($user_id);
		$attr_details = $this->category_model->getCartAttrByUserId($user_id);
	   	$total_price='';
	    	$total_qty = '';
	   	foreach ($cart_details as $c_value) 
	   	{
        		$total_price = $total_price + $c_value->cart_total_price;
			 $total_qty = $total_qty + $c_value->cart_product_qty;
		}
		//echo $total_price;die;
		if(!empty($cart_details))
		{
			echo json_encode(array("status"=>1, "cart_details"=>$cart_details, "attr_details"=>$attr_details, "total_price"=>$total_price, "total_qty"=>$total_qty));
		}
		else
		{
			echo json_encode(array("status"=>0));
		}
	} 
   	public function deleteCart()
	{
		$user_id = $_GET['user_id'];
		$cart_product_id = $_GET['product_id'];	        
		$delete_cart_list = $this->category_model->deleteCartByUserId($user_id,$cart_product_id);
		
		if(!empty($delete_cart_list))
		{	  
			 echo json_encode(array("status"=>1));		
		}
		else
		{
			echo json_encode(array("status"=>0));
		}
	} 
	public function updateCartQty()
	{	
		$post['cart_user_id'] = $_GET['user_id'];
		$post['cart_product_id'] = $_GET['product_id'];
        	$post['cart_product_qty'] = $_GET['cart_product_qty'];
        	$total_price = $_GET['cart_total_price'];        
		$post['cart_total_price']= $post['cart_product_qty'] * $total_price;		
        	$update_cart_list = $this->category_model->updateCartQty($post);			
		if(!empty($update_cart_list))
		{
			echo json_encode(array("status"=>1));
		}
		else
		{
			echo json_encode(array("status"=>0));
		}
		
	} 
	/************************************* END CART ******************************************/

  	/************************************* END SOCIAL LOGIN ***********************************/
  	public function countryList()
  	{
  		$country_list = $this->category_model->getCountryList();
  		if(!empty($country_list))
		{
			echo json_encode(array("status"=>1, "country_list"=>$country_list));
		}
		else
		{
			echo json_encode(array("status"=>0));
		}
  	}
  	public function stateList()
  	{
  		$country_id = $_GET['country_id'];
  		$state_list = $this->category_model->getStateList($country_id);
  		if(!empty($state_list))
		{
			echo json_encode(array("status"=>1, "state_list"=>$state_list));
		}
		else
		{
			echo json_encode(array("status"=>0));
		}
  	}
	public function addSocialUser()
	{
		if($_GET['login_type'] == 'N')
		{
	            $post['user_name'] = $_GET['name'];
	            $post['user_email'] = $_GET['email'];
	            $post['user_phone'] = $_GET['phone'];
	            $post['user_password'] = $_GET['user_password'];
	            $post['user_dob'] = $_GET['user_dob'];
	            $post['user_address_1'] = $_GET['address_1'];
	            $post['user_address_2'] = $_GET['address_2'];
	            $post['user_city'] = $_GET['city'];
	            $post['user_state_id'] = $_GET['state_id'];
	            $post['user_country_id'] = $_GET['country_id'];
	            $post['user_postal_code'] = $_GET['postal_code'];
	            $post['user_type'] = 'n_user';
	            $post['login_type'] = $_GET['login_type'];
	            $post['user_created_date'] = date('Y-m-d');
		    $post['user_updated_date'] = date('Y-m-d');
		    $check['unick_user'] = $_GET['email'];
		    $check['login_type'] = 'N';
             
		}
		else if($_GET['login_type'] == 'F')
		{
	           $post['user_name'] = $_GET['name'];
	           $post['user_email'] = $_GET['email'];
	           $post['login_type'] = $_GET['login_type'];
	           $post['user_img_url'] = $_GET['img_url'];
	           $post['user_social_id'] = $_GET['social_id'];
	           $post['user_created_date'] = date('Y-m-d');
		   $post['user_updated_date'] = date('Y-m-d');
		   $check['unick_user'] = $_GET['social_id'];
		   $check['login_type'] = $_GET['login_type'];
		
		}
		else if($_GET['login_type'] == 'G')
		{
	           $post['user_name'] = $_GET['name'];
	           $post['user_email'] = $_GET['email'];
	           $post['login_type'] = $_GET['login_type'];
	           $post['user_img_url'] = $_GET['img_url'];
	           $post['user_social_id'] = $_GET['social_id'];
	           $post['user_created_date'] = date('Y-m-d');
		   $post['user_updated_date'] = date('Y-m-d');
		   $check['unick_user'] = $_GET['social_id'];
		   $check['login_type'] = $_GET['login_type'];
		}
        	$check_user = $this->category_model->checkSocialUser($check);	
		if(empty($check_user))
  		{       
		 	$login_id = $this->category_model->addSocialUser($post);
		  	if(!empty($login_id))
			{
			  	echo json_encode(array("status"=>1, "user_id"=>$login_id, "user_email"=>$_GET['email'], "user_name"=>$_GET['name'], "user_type"=>$_GET['login_type']));
			}
			else
			{
				echo json_encode(array("status"=>0));
			}
   	    	}
   	   	else
   	    	{
   	    		echo json_encode(array("status"=>2));
   	    	}
    	}
    	public function login()
    	{
	    	$post['user_email'] = $_GET['user_email'];
	    	$post['user_password'] = $_GET['user_password'];
	    	$user_detail = $this->category_model->loginUser($post);
	    	if(!empty($user_detail))
		{
			$post['user_id'] = $user_detail[0]->user_id;
			$post['user_log_status'] = 1; 
			$this->category_model->updateloginStatus($post);

		  	echo json_encode(array("status"=>1, "user_id"=>$user_detail[0]->user_id, "user_email"=>$user_detail[0]->user_email, "user_name"=>$user_detail[0]->user_name, "user_type"=>$user_detail[0]->user_type));
		}
		else
		{
			echo json_encode(array("status"=>0));
		}
    	}
    	public function logout()
	{		
		$post['user_id'] = $_GET['user_id'];
		$post['user_log_status'] = 0; 
		$res = $this->category_model->updateloginStatus($post);
		if($res=='1')
		{
			echo json_encode(array("status"=>1)); 
		}
		else
		{
			echo json_encode(array("status"=>0)); 
		}
	}
	public function showProfile()
	{
		$user_id = $_GET['user_id']; 
		$user_detail = $this->category_model->showProfile($user_id);
		if(!empty($user_detail))
		{
			echo json_encode(array("status"=>1, "user_detail"=>$user_detail)); 
		}
		else
		{
			echo json_encode(array("status"=>0)); 
		}
	}
    	public function profile()
    	{  
	    	$post['user_id'] = $_GET['user_id'];       
	    	$post['user_name'] = $_GET['name'];       
	        $post['user_phone'] = $_GET['phone'];
	        $post['user_dob'] = $_GET['user_dob'];
	        $post['user_address_1'] = $_GET['address_1'];
	        $post['user_address_2'] = $_GET['address_2'];
	        $post['user_city'] = $_GET['city'];
	        $post['user_state_id'] = $_GET['state_id'];
	        $post['user_country_id'] = $_GET['country_id'];
	        $post['user_postal_code'] = $_GET['postal_code'];
		    $post['user_updated_date'] = date('Y-m-d');
	    	$user_update = $this->category_model->updateProfile($post);
	    	$user_detail = $this->category_model->showProfile($post['user_id']);
	    	if($user_update == 'true')
		{
		  	echo json_encode(array("status"=>1, "user_id"=>$user_detail[0]->user_id, "user_email"=>$user_detail[0]->user_email, "user_name"=>$user_detail[0]->user_name, "user_type"=>$user_detail[0]->user_type));
		}
		else
		{
			echo json_encode(array("status"=>0));
		}
    	}
	public function changePassword()
    	{
    		$post['user_id'] = $_GET['user_id'];       
    		$post['user_password'] = $_GET['user_password'];  
	    	$post['user_updated_date'] = date('Y-m-d');
    		$user_detail = $this->category_model->changePassword($post);

    		if($user_detail == 'true')
		{
		  	echo json_encode(array("status"=>1));
		}
		else
		{
			echo json_encode(array("status"=>0));
		}
    	}
   	public function showUserAllAddress()
   	{
   		$user_id = $_GET['user_id'];       
   		$user_address_type = $_GET['user_address_type'];    
   		$user_address = $this->category_model->getUserAddress($user_id, $user_address_type);
    		
    		if($user_address)
		{
		  	echo json_encode(array("status"=>1, "user_address"=>$user_address));
		}
		else
		{
			echo json_encode(array("status"=>0));
		}
   	}

   	public function addUserAddress()
   	{
   		$post['user_id'] = $_GET['user_id'];       
   		$post['user_address_type'] = $_GET['user_address_type'];       
   		$post['user_address_name'] = $_GET['user_address_name'];       
   		$post['user_address_phone'] = $_GET['user_address_phone'];       
   		$post['user_address_mobile'] = $_GET['user_address_mobile'];       
   		$post['user_address_1'] = $_GET['user_address_1'];       
   		$post['user_address_2'] = $_GET['user_address_2'];       
   		$post['user_address_country_id'] = $_GET['user_address_country_id'];       
   		$post['user_address_state_id'] = $_GET['user_address_state_id'];       
   		$post['user_address_city'] = $_GET['user_address_city'];       
   		$post['user_address_postalcode'] = $_GET['user_address_postalcode'];  
    		$user_address = $this->category_model->addUserAddress($post);   
    		$aaa = $this->category_model->getUserAddressByAddressID($post['user_id'], $user_address); 

    		if($user_address)
		{
		  	echo json_encode(array("status"=>1));
		}
		else
		{
			echo json_encode(array("status"=>0));
		}
   	}

   	public function setDefaultAddress()
   	{
   		$post['user_id'] = $_GET['user_id'];       
   		$post['user_address_id'] = $_GET['user_address_id'];
		$this->category_model->updateDefaultAddressStatusN($post);
		$user_address = $this->category_model->updateDefaultAddressStatusY($post);

    		if($user_address == 'true')
		{
		  	echo json_encode(array("status"=>1));
		}
		else
		{
			echo json_encode(array("status"=>0));
		}
   	}

   	public function showDefaultAddress()
   	{
   		$user_id = $_GET['user_id'];          		
		$user_address = $this->category_model->showDefaultAddress($user_id);

    		if($user_address)
		{
		  	echo json_encode(array("status"=>1, "user_address"=>$user_address));
		}
		else
		{
			echo json_encode(array("status"=>0));
		}
   	}

   	public function showUserAddressByAddressID()
   	{
   		$user_id = $_GET['user_id'];       
   		$user_address_id = $_GET['user_address_id'];       
    		$user_address = $this->category_model->getUserAddressByAddressID($user_id, $user_address_id);

    		if($user_address)
		{
		  	echo json_encode(array("status"=>1, "user_address"=>$user_address));
		}
		else
		{
			echo json_encode(array("status"=>0));
		}
   	}
   	public function updateUserAddressByAddressID()
   	{
   		$post['user_id'] = $_GET['user_id'];       
   		$post['user_address_id'] = $_GET['user_address_id'];       
   		$post['user_address_name'] = $_GET['user_address_name'];       
   		$post['user_address_phone'] = $_GET['user_address_phone'];       
   		$post['user_address_mobile'] = $_GET['user_address_mobile'];       
   		$post['user_address_1'] = $_GET['user_address_1'];       
   		$post['user_address_2'] = $_GET['user_address_2'];       
   		$post['user_address_country_id'] = $_GET['user_address_country_id'];       
   		$post['user_address_state_id'] = $_GET['user_address_state_id'];       
   		$post['user_address_city'] = $_GET['user_address_city'];       
   		$post['user_address_postalcode'] = $_GET['user_address_postalcode'];  

    		$user_address = $this->category_model->updateUserAddressByAddressID($post);

    		if($user_address == 'true')
		{
		  	echo json_encode(array("status"=>1));
		}
		else
		{
			echo json_encode(array("status"=>0));
		}
   	}
   	public function deleteUserAddressByAddressID()
   	{
   		$post['user_id'] = $_GET['user_id'];       
   		$post['user_address_id'] = $_GET['user_address_id'];       
   		$user_address = $this->category_model->deleteUserAddressByAddressID($post);

    		if($user_address)
		{
		  	echo json_encode(array("status"=>1));
		}
		else
		{
			echo json_encode(array("status"=>0));
		}
   	}
	/****************************** END SOCIAL USER ***************************************/
	
	/****************************** START COUPAN ***************************************/	
	public function applyCouponCode()
	{
		$post['coupon_date'] = $_GET['coupon_date']; 
		$post['user_email'] = $_GET['user_email'];		
		$post['coupon_code'] = $_GET['coupon_code'];		           
       
       		$coupon_res = $this->category_model->applyCouponCode($post);
      
		if(!empty($coupon_res))
		{
			$status = $this->category_model->updateCouponCodeStatus($post);
			if($status == 'true')
			{
				echo json_encode(array("status"=>1, "coupon_res"=> $coupon_res));
			}
			else
			{
				echo json_encode(array("status"=>2));
			}			
		}
		else
		{
     	   		echo json_encode(array("status"=>0));
		}	 	
  	}
	/****************************** END COUPAN ***************************************/
	/****************************** Start Event Booking *************************************/
	public function eventBooking()
	{
		// echo "<pre>";
		// print_r($_GET);
		// die();
		$post['event_id'] = $_GET['event_id']; 
		$post['user_id'] = $_GET['user_id'];		
		$post['event_booking_total_price'] = $_GET['total_price'];		           
		$post['event_booking_transaction_id'] = $_GET['transaction_id'];		           
		$post['event_booking_payment_status'] = $_GET['event_booking_payment_status'];           
		$post['event_booking_created_date'] = date('Y-m-d');		           
		$post['event_booking_updated_date'] = date('Y-m-d');

		$event_booking_id = $this->category_model->addEventBookingDetail($post);

		$attr_detail = $_GET['attr_detail'];		           
		$att_r = explode(',', $attr_detail);
		for($i=0; $i<count($att_r); $i++)
		{
			$att_r_val = explode('_', $att_r[$i]);
			$attr_post['event_id'] = $post['event_id']; 
			$attr_post['user_id'] = $post['user_id']; 
			$attr_post['event_booking_id'] = $event_booking_id; 
			$attr_post['attr_id'] = $att_r_val[0]; 
			$attr_post['attr_val_id'] = $att_r_val[1]; 
			$this->category_model->addEventBookingAttributes($attr_post);
		}

		$event_Detail = $this->category_model->eventDetailByEventId($post['event_id']);           
		if($event_Detail[0]->event_day_slote_status == '1')
		{
			$date_time_id = $_GET['date_time_id'];	
			$date_time_r = explode(',', $date_time_id);	           
			for($j=0; $j<count($date_time_r); $j++)
			{
				$date_post['event_id'] = $post['event_id']; 
				$date_post['user_id'] = $post['user_id']; 
				$date_post['event_booking_id'] = $event_booking_id; 
				$date_post['event_date_time_id'] = $date_time_r[$j]; 
				$this->category_model->addEventBookingDateTime($date_post);
			}
		}
		if(!empty($event_booking_id))
		{
			echo json_encode(array("status"=>1));	
		}
		else
		{
     	  		echo json_encode(array("status"=>0));
		}	 	
  	}

  	public function eventBookingHistory()
   	{
   		$user_id = $_GET['user_id'];    
   		$event_booking_history = $this->category_model->showEventBookingHistory($user_id);   	
   		$event_booking_attribute = $this->category_model->showEventBookingAttributesHistory($user_id);  

   		$event_booking_date_time = $this->category_model->showEventBookingDateTime($user_id); 

    		if($event_booking_history)
		{
		  	echo json_encode(array("status"=>1, "event_booking_history"=>$event_booking_history, "event_booking_attribute"=>$event_booking_attribute, "event_booking_date_time"=>$event_booking_date_time));
		}
		else
		{
			echo json_encode(array("status"=>0));
		}
   	}

	/****************************** END Event Booking ***************************************/
	/****************************** Start Guest Checkout ***************************************/
	public function guestCheckOut()
	{
		$post['guest_user_name'] = $_GET['guest_user_name']; 
		$post['guest_user_email'] = $_GET['guest_user_email'];		
		//$post['guest_user_phone'] = $_GET['guest_user_phone'];		
		$post['guest_user_mobile'] = $_GET['guest_user_mobile'];		           		
		$post['guest_user_type'] = 'GU';		           		
		$post['guest_user_created_date'] = date('Y-m-d');		           
		$post['guest_user_updated_date'] = date('Y-m-d');	
		$guest_user_id = $this->category_model->addGuestUser($post);
		
		$post_address['guest_user_address_type'] = 'B';		           
		$post_address['guest_user_id'] = $guest_user_id; 
		$post_address['guest_user_address1'] = $_GET['guest_user_address1'];		           
		$post_address['guest_user_address2'] = $_GET['guest_user_address2'];		           
		$post_address['guest_user_city'] = $_GET['guest_user_city'];		           
		$post_address['guest_user_country_id'] = $_GET['guest_user_country_id'];		        
		$post_address['guest_user_state_id'] = $_GET['guest_user_state_id'];		           
		$post_address['guest_user_postal_code'] = $_GET['guest_user_postal_code'];	           
		$this->category_model->addGuestUserAddress($post_address);   

		$post_address['guest_user_address_type'] = 'D';		           
		$post_address['guest_user_id'] = $guest_user_id; 
		$post_address['guest_user_address1'] = $_GET['guest_user_address1_s'];		           
		$post_address['guest_user_address2'] = $_GET['guest_user_address2_s'];		           
		$post_address['guest_user_city'] = $_GET['guest_user_city_s'];		           
		$post_address['guest_user_country_id'] = $_GET['guest_user_country_id_s'];		        
		$post_address['guest_user_state_id'] = $_GET['guest_user_state_id_s'];		           
		$post_address['guest_user_postal_code'] = $_GET['guest_user_postal_code_s'];	           
		$this->category_model->addGuestUserAddress($post_address);    
       
		if(!empty($guest_user_id))
		{
			echo json_encode(array("status"=>1, "user_id"=> $guest_user_id, "user_type"=> $post['guest_user_type'], "user_email"=> $post['guest_user_email'], "user_name"=> $post['guest_user_name']));		
		}
		else
		{
     	   		echo json_encode(array("status"=>0));
		}	 	
  	}
  	
  	public function showGuestUserAddress()
  	{
  		$user_id = $_GET['user_id'];       		
   		$user_address = $this->category_model->getGuestUserAddress($user_id);
   		$user_detail = $this->category_model->getGuestUser($user_id);
    		
    		if($user_address)
		{
		  	echo json_encode(array("status"=>1, "user_address"=>$user_address, "user_detail"=>$user_detail));
		}
		else
		{
			echo json_encode(array("status"=>0));
		}
  	}
	/****************************** END Guest Checkout ***************************************/

/* End of file */
}
?>